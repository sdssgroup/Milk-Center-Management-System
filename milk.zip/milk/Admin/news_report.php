<?php
include("sidebar.php");
if($_SESSION['user_type']=='Administrator'){
?>
<title>News Board</title>
<div class="container">
<?php
$results_per_page=10;
$news_sql="select * from news where status='Active'";
$news_result=$conn->query($news_sql);
$result_no=mysqli_num_rows($news_result);
$number_of_pages=ceil($result_no/$results_per_page);
if(!isset($_GET['page'])){
	$page=1;
}else{
	$page=$_GET['page'];
}
$start=($page-1)*$results_per_page;

$news_sql="select * from news where status='Active' LIMIT ".$start.",".$results_per_page;
$news_result=$conn->query($news_sql);
?>
<table border="1" width="80%">
<thead><tr><th>Date</th><th>Title</th><th>Description</th><th>File</th></tr></thead>
<tbody>
<?php
while($news_row=mysqli_fetch_array($news_result)){
?>
<tr><td><?php echo $news_row['created_date']; ?></td>
<td><?php echo $news_row['title']; ?></td>
<td><?php echo "<pre>".$news_row['description']."</pre>"; ?></td>
<td><a href="../uploads/news/<?php echo $news_row['file_location']; ?>"  target="_blank"><img src="../images/downloadpdf.png" width="50px" height="auto"/></a></td></tr>
<?php 
}
?>
<tr><td colspan="4" align="center"><?php
for($page=1;$page<=$number_of_pages;$page++){
	echo "<a href='news_report?page=".$page."'>".$page."</a> ";
}
?></td></tr>
</tbody></table>

  </div></div>          
        </div>
</body>
</html>
<?php
include("footer.php");
}else{
	echo "Invalid User";
}
?>