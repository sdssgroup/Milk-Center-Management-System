<?php
include("sidebar.php");
if($_SESSION['user_type']=='Administrator'){
?>
<title>Edit Feedback</title>
<div class="container">
<form method="post" action="">
<table border="1" width="75%">
<?php
$fb_sql="select * from feedback where id='".mysqli_real_escape_string($conn,$_GET['id'])."'";
$fb_results=$conn->query($fb_sql);
$fb_row=mysqli_fetch_array($fb_results)?><tr>
<td>User ID</td><td><input type="text" readonly placeholder="User ID" name="user_id" value="<?php echo $fb_row['user_id']; ?>"></td>
</tr><tr><td>Name</td><td><input width="auto" type="text" readonly placeholder="Name" name="name" value="<?php echo $fb_row['name']; ?>"></td>
</tr><tr><td>Feedback Given</td><td><pre><?php echo $fb_row['feedback']; ?></pre></td>
</tr><tr><td>Suggestion Given</td><td><pre><?php echo $fb_row['suggestion']; ?></pre></td>
</tr><tr><td>Reply</td><td><textarea required name="reply"><?php echo $fb_row['reply_to_suggestion']; ?></textarea></td>
</tr><tr><td>Feedback Date</td><td><input type="date" readonly placeholder="Date created" name="date_created" value="<?php echo $fb_row['date_created']; ?>"></td>
</tr><tr><td>Solved date</td><td><input type="date" required placeholder="Date Solved" name="date_solved" value="<?php echo date('Y-m-d'); ?>"></td>
</tr><tr align="center"><td colspan="2"><input style="background:rgb(25,20,150); color:white" type="submit" name="submit" value="Submit"></td>
</tr>
<?php
if(isset($_POST['submit'])){
	$feedback_id=mysqli_real_escape_string($conn,$_GET['id']);
	$username=$fb_row['name'];
	$date_solved=date('Y-m-d');
	$reply=$_POST['reply'];
	$fb_query=mysqli_query($conn,"update feedback set reply_to_suggestion='$reply',feedback_status='Solved', date_solved='$date_solved' where id='$feedback_id'");
	if($fb_query){
		echo "<script>alert('Feedback resolved Sucessfully'); window.location='view_feedback.php';</script>";
	}
}
?>
</table>
</form>
</div>
            </div>
        </div>
</body>
</html>
<?php
include("footer.php");
}else{
	echo "Invalid User";
}
?>