<?php
include("sidebar.php");
if($_SESSION['user_type']=='Administrator'){
?>
<title>Admin Dashboard</title>
                <!-- container -->
                <div class="container">
                    <!-- news -->
                    <div class="card" id="news">
                        <!-- card title  -->
                        <div class="card-title">
                            Reports/News
                        </div>
                        <!-- card content -->
                        <div class="card-content">
                            <ul>
							<li><a href="news_report">News Report</a></li>
                            <li><a href="change_password_report.php">Change Password Report</a></li>
                            <li><a href="datewise_entry_all_users.php">All user entry</a></li>
                            </ul>
                        </div>
                    </div>

                    <!-- attendance  -->
                    <div class="card" id="attendance">
                        <!-- card title  -->
                        <div class="card-title">
                            Attendance
                        </div>
                        <!-- card content -->
                        <div class="card-content">

                        </div>
                    </div>

                    <!-- schedule  
                    <div class="card" id="schedule">
                        <!-- card title  
                        <div class="card-title">
                            Reports
                        </div>
                        <!-- card content 
                        <div class="card-content">
                            <ul>
                                <li><a href="change_password_report.php">Change Password Report</a></li>
                            </ul>
                        </div>
                    </div>-->

                    <!-- progress  -->
                    <div class="card" id="progress">
                        <!-- card title  -->
                        <div class="card-title">
                            Reports
                        </div>
                        <!-- card content -->
                        <div class="card-content" style="height:auto;">
                            <ul>
                            <li><a href="bill_generation_report_userwise.php" onclick="onLinkClick()">Bill Generation Report(Userwise) </a></li>
                            <li><a href="bill_generation_report_datewise.php" onclick="onLinkClick()">Bill Generation Report(Datewise) </a></li>
                            <li><a href="datewise_entry_report.php" onclick="onLinkClick()"> Datewise Report </a></li>
                            <li><a href="userwise_report.php" onclick="onLinkClick()"> Userwise Report </a></li>
                            <li><a href="view_feedback.php" onclick="onLinkClick()"> Feedback Report</a></li>
                            <li><a href="view_contact_us.php" onclick="onLinkClick()"> Contact Us Report </a></li>
                            </ul>
                        </div>
                    </div>

                    <!-- pending work  -->
                    <div class="card" id="pending-work">
                        <!-- card title  -->
                        <div class="card-title">
                            Pending Work
                        </div>
                        <!-- card content -->
                        <div class="card-content">
                            <ul>
                                <li>Under Construction</li>
                            </ul>
                        </div>
                    </div>
                </div>
				
            </div>
        </div>
    </body>
	
<?php
include("footer.php");
}else{
	echo "INVALID USER";
}
?>
</html>