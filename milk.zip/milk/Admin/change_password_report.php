<?php
include("sidebar.php");
if($_SESSION['user_type']=='Administrator'){
	$session_id=$_SESSION['id'];
	$sai="select * from users where user_id='$session_id'";
	$sai_query=$conn->query($sai);
	$row=mysqli_fetch_array($sai_query);
?>
<title>Password Recovery Report</title>
<div class="container">
<table width="80%" border="1">
<thead><tr><th colspan="6">Password Recovery Report</th></tr>
<tr><th>Username</th><th>Name</th><th>Old Password</th><th>New Password</th><th>Date Changed</th><th>IP Address</th></tr></thead>
<tbody>
<?php
$sql="select * from change_password";
$query=$conn->query($sql);
while($num_row=mysqli_fetch_array($query)){
?>
<tr><td><?php echo $num_row['username']?></td>
<td><?php echo $num_row['name']?></td>
<td><?php echo $num_row['old_password']?></td>
<td><?php echo $num_row['new_password']?></td>
<td><?php echo $num_row['date_changed']?></td>
<td><?php echo $num_row['ip_address']?></td>
</tr>
<?php
}?>
</tbody>
</table>

 </div>
            </div>
        </div>
		
    </body>
<?php
include("footer.php");
}else{
	echo "Invalid User";
}
?>
</html>