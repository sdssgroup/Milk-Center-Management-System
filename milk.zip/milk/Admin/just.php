<?php
include("connect_db.php");
//$query="update datewise_entry set user_id='24' where name='DASARI INDHRAMMA'";
//$sql=$conn->query($query);
echo "This page is not working now.";
?>