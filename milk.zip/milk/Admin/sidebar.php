<?php
//Start session
session_start();
//Check whether the session variable SESS_MEMBER_ID is present or not
if (!isset($_SESSION['id']) || (trim($_SESSION['id']) == '')) {
    header("location: index.php");
    exit();
}
$session_id=$_SESSION['id'];
if($_SESSION['user_type']=='Administrator'){
?>

<?php
include("connect_db.php");
$sql="select * from users where user_id='$session_id'";
$query=$conn->query($sql);
$row=mysqli_fetch_array($query);
$date=date("Y-m-d");
$s="select * from datewise_entry where date='$date'";
$q=$conn->query($s);
$lite=mysqli_fetch_array($q);
$num_count=mysqli_num_rows($q);
$s_u="select * from users where user_type='User'";
$q_u=$conn->query($s_u);
$lite_u=mysqli_fetch_array($q_u);
$num_count_u=mysqli_num_rows($q_u);
$attendance=($num_count/($num_count_u))*100;
?>
<!DOCTYPE html>
<link rel="stylesheet" href="../css/admin_sidebar.css">
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link rel="stylesheet" href="styles.css">
        <link href="https://fonts.googleapis.com/css?family=Raleway&display=swap" rel="stylesheet">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/p5.js/0.8.0/p5.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <!-- little jquery for hiding menu  -->
        <script>
            function setup() {
                var can = createCanvas(300, 200);
                can.parent('attendance');
                textSize(32);
                frameRate(60);
            }
            var x = 1.0001;
            var start = 0;
            var pX = 0;
            var pXAnim = 0;
            radius = 0;

            function draw() {
                if (start == 1) {
                    background('rgba(0,0,0,0)');
                    clear();
                    stroke(0);
                    strokeWeight(0.1);
                    fill(0);
                    if (pXAnim < pX) {
                        pXAnim += 0.7;
                    }
                    text(int(pXAnim) + "%", 75 + 50, 75 + 20);
                    stroke('#3f51b5ff');
                    strokeWeight(4);
                    fill('rgba(0,0,0,0)');

                    if (x <= (1.33 * pX / 100) + 1) {
                        x += 0.01;
                    }
                    if (radius < 12) {
                        radius += 0.2;
                    }
                    arc(75 + 80, 75 + 10, 150, 150, 3 * PI / 2, x * 3 * PI / 2);
                    findPoint(150 / 2, x * 3 * PI / 2, radius);
                } else {
                    //not uploaded   
                }



            }

            function startDrawing(percent) {
                start = 1;
                pX = percent;


            }

            function findPoint(radius, angle, r) {
                var x = Math.sin(angle) * radius;
                var y = Math.cos(angle) * radius;
                fill('#3f51b5ff')
                circle(y + 75 + 80, x + 75 + 10, r);
            }

            function windowSizeCheck() {
                if ($(window).width() < 700) {
                    $('.menu').addClass("menu-hide");
                    $('.menu').removeClass("menu");
                    $('.custom-menu-button-side-hide').addClass("custom-menu-button-side-view");
                    $('.custom-menu-button-side-view').removeClass("custom-menu-button-side-hide");
                    $('.custom-menu-button-hide').addClass("custom-menu-button-view");
                    $('.custom-menu-button-view').removeClass("custom-menu-button-hide");
                }
            }

            $(window).resize(() => {
                if ($(window).width() < 700) {
                    $('.menu').addClass("menu-hide");
                    $('.menu').removeClass("menu");
                    $('.menu-button').addClass("menu-button-view");
                    $(".menu-button-view").removeClass("menu-button");

                    $('.custom-menu-button-hide').addClass('custom-menu-button-view');
                    $('.custom-menu-button-view').removeClass('custom-menu-button-hide');
                    $('.custom-menu-button-side-hide').addClass('custom-menu-button-side-view');
                    $('.custom-menu-button-side-view').removeClass('custom-menu-button-side-hide');
                } else {
                    $('.menu-hide').addClass("menu");
                    $('.menu').removeClass("menu-hide");
                    $('.menu').removeClass("menu-view-animation");
                    $('.menu').removeClass("menu-hide-animation");
                    $(".menu-button-view").addClass("menu-button");
                    $('.menu-button').removeClass("menu-button-view");

                    $('.custom-menu-button-view').addClass('custom-menu-button-hide');
                    $('.custom-menu-button-hide').removeClass('custom-menu-button-view');

                    $('.custom-menu-button-side-view').addClass('custom-menu-button-side-hide');
                    $('.custom-menu-button-side-hide').removeClass('custom-menu-button-side-view');

                    $('.grey-overlay-hide').addClass("grey-overlay");
                    $('.grey-overlay').removeClass("grey-overlay-hide");
                }
            })

            var temp = false;

            function onMenuClick() {
                temp = !temp;
                if (temp) {
                    $('.menu-hide').addClass("menu-view-animation");
                    $('.menu-hide').removeClass("menu-hide-animation");

                    $('.grey-overlay').addClass("grey-overlay-hide");
                    $('.grey-overlay-hide').removeClass("grey-overlay");

                } else {
                    $('.menu-hide').addClass("menu-hide-animation");
                    $('.menu-hide').removeClass("menu-view-animation");

                    $('.grey-overlay-hide').addClass("grey-overlay");
                    $('.grey-overlay').removeClass("grey-overlay-hide");
                }
            }

            function onLinkClick() {
                console.log("link clicked");
                temp = false;
                $('.menu-hide').addClass("menu-hide-animation");
                $('.menu-hide').removeClass("menu-view-animation");
                $('.grey-overlay-hide').addClass("grey-overlay");
                $('.grey-overlay').removeClass("grey-overlay-hide");
            }

            function startDrawingPie(percent) {
                setTimeout(() => {
                    startDrawing(percent);
                }, 700)
            }

        </script>
    </head>

    <body onload="startDrawingPie(<?php echo $attendance;?>); windowSizeCheck();">
        <div class="grey-overlay">

        </div>
        <!-- application  -->
        <div class="application">
            <!-- navbar -->
            <div class="navbar">
                <!-- navbar heading -->
                <div class="navbar-heading">
                    <!-- <button class="menu-button" onclick="onMenuClick()"> MENU </button> -->
                    <div class="custom-menu-button-hide" onclick="onMenuClick()">
                        <div></div>
                        <div></div>
                        <div></div>
                    </div>
                    <h3 class="navbar-heading-title">Milk Co-operation of Telangana State</h3>
                </div>

                <div class="navbar-content">
                    <h4 style="color:white">Kadaparthy, Nakrekal, Nalgonda</h4>

                </div>
            </div>

            <div class="main">
                <!-- menu -->
                <div class="menu">
                    <!-- <button class="menu-button-side-hide" onclick="onMenuClick()"> MENU </button> -->
                    <div class="custom-menu-button-side-hide" onclick="onMenuClick()">
                        <div></div>
                        <div></div>
                        <div></div>
                    </div>
                    <!-- profile image  -->
                    <div class="menu-profile">
                        <img src="../images/<?php if($row['photo']!=''){echo $row['photo'];}else{echo "default.png";} ?>" alt="Profile" srcset="">
                    </div>

                    <div style="text-align: center; margin-top: 5px; font-size: 20px;"> <?php echo $row['name']; ?><br><?php echo $row['user_type']; ?> </div>
                    <!-- menu content  -->
                    <div class="menu-content">
                        <ul>
                            <li><a href="dashboard.php" onclick="onLinkClick()"> Home </a></li>
                            <li><a href="reports.php" onclick="onLinkClick()"> Reports </a></li>
                            <li><a href="ratelist.php" onclick="onLinkClick()"> Ratelist </a></li>
                            <li><a href="datewise_entry.php" onclick="onLinkClick()"> Datewise Entry </a></li>
                            <li><a href="generate_bill.php" onclick="onLinkClick()"> Generate Bill </a></li>
                            <li><a href="news_post.php" onclick="onLinkClick()"> Post News </a></li>
                            <li><a href="create_user.php" onclick="onLinkClick()"> Create User </a></li>
                            <li><a href="change_password.php" onclick="onLinkClick()"> Change Password </a></li>
                            <li><a href="logout.php" onclick="onLinkClick()"> Logout </a></li>
                        </ul>
                    </div>
                </div>
<?php
}
?>