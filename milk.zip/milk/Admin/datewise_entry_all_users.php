<?php
include("sidebar.php");
if($_SESSION['user_type']=='Administrator'){
?>
<style>
.alert.danger {
  padding: 20px;
  background-color: #f44336;
  color: white;
}
.alert.success {
  padding: 20px;
  background-color: #4CAF50;
  color: white;
}

.closebtn {
  margin-left: 15px;
  color: white;
  font-weight: bold;
  float: right;
  font-size: 22px;
  line-height: 20px;
  cursor: pointer;
  transition: 0.3s;
}

.closebtn:hover {
  color: black;
}
</style>
<title>Datewise Entry</title>
<div class="container">
<fieldset style="width:50%; "><legend>Enter the Post details: <?php echo date('d-m-Y'); ?> </legend>
<form action="" enctype="multipart/form-data" method="post">
<table>
<thead>
<tr align="center" height="50px" style="background:pink"><td>Date</td><td colspan="2"><input type="date" placeholder="Date" value="" name="date" required></td>
<td>Session</td><td colspan="2"><select name="session">
	<option value="Morning">Morning</option>
	<option value="Evening">Evening</option></select></td></tr>
<tr style="background:rgb(210,210,220)"><td>User Id</td><td>Name</td><td>Sample Number</td><td>Liters</td><td>Fat</td><td>Milk Type</td></tr>
</thead>
<tbody>
<?php
$query1=mysqli_query($conn,"select * from users where user_type='user' and status='active'");
while($row1=mysqli_fetch_array($query1)){
	?>
	<tr height="30px"><td><input type="text" name="user_id[]" value="<?php echo $row1['user_id'];?>" required readonly></td>
	<td><input type="text" name="name[]" value="<?php echo $row1['name'];?>" required readonly></td>
	<td><input type="number" name="sample_no[]" placeholder="Sample number" ></td>
	<td><input type="text" name="liter[]" placeholder="Liters" ></td>
	<td><input type="text" name="fat[]" placeholder="Fat" ></td>
	<td><select name="milk_type[]">
	<option value="Buffalo">Buffalo</option>
	<option value="Cow">Cow</option></select></td>
	</tr>
<?php
}
?>
<tr align="center"><td colspan="6"><input type="submit" id="submit" name="submit" value="Submit"></td></tr>
</tbody>
</table>
</form>
 <center>

<?php
if(isset($_POST['submit']))
{ 
$date=$_POST['date'];
$check_query=mysqli_query($conn,"select * from datewise_entry where date='".$date."' and user_id=''  and session='".$_POST['session']."'");
if(mysqli_num_rows($check_query)>0)
{?>
<div class="alert danger">
  <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span> 
  <strong>Already Inserted!</strong>
</div>
<?php
}else{
	$count=0;
for($i=0;$i<mysqli_num_rows($query1);$i++){
	if($_POST['milk_type']=='Cow' && $_POST['fat']>5){
		$_POST['fat']=5;
	}
	if($_POST['milk_type']=='Buffalo' && $_POST['fat']>12){
		$_POST['fat']=12;
	}
	if($_POST['sample_no'][$i]=='' && $_POST['fat'][$i]=='' && $_POST['liter'][$i]==''){
	}else{
	$query_rate=mysqli_query($conn,"select * from data where fat='".$_POST['fat'][$i]."' and milk_type='".$_POST['milk_type'][$i]."'");
	$row_rate=mysqli_fetch_array($query_rate);
	$insert="insert into datewise_entry (user_id,name,liters,fat,rate,date,session,sample_no,milk_type)
	values('".$_POST['user_id'][$i]."','".$_POST['name'][$i]."','".$_POST['liter'][$i]."','".$_POST['fat'][$i]."','".$row_rate['rate']."','".$date."','".$_POST['session']."','".$_POST['sample_no'][$i]."','".$_POST['milk_type'][$i]."')";
	$execute=$conn->query($insert);
	if($execute){
		$count=$count+1;
	}else{?>
<div class="alert danger">
  <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span> 
  <strong>Problem incured in insertion contact developer!</strong>
</div>
<?php
		
	}
	}
}?>
<div class="alert success">
  <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span> 
  <strong><?php echo $count;?> Queries Successfully Inserted!</strong>
</div>
<?php
}
}
?>
</fieldset></div>
            </div>
        </div>
</body>
</html>
<?php
include("footer.php");
}else{
	echo "Invalid User";
}
?>