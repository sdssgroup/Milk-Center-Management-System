<?php
include("sidebar.php");
if($_SESSION['user_type']=='Administrator'){
?>
<title>Datewise Report</title>
<div class="container">
<form method="post" action="">
<table><tr><td><label>Date</label></td><td>:</td>
<td><input type="date" id="name" name="date" value=""></td>
<td colspan="3" align="center"><input type="submit" name="submit" value="OK"></td></tr>
</form></table><br><br>
				<div>
                </div>
<?php
if(isset($_POST['submit'])){
	$date=$_POST['date'];
	$tp=0;
	$sl="select * from datewise_entry where date='$date'";
	$list= $conn->query($sl);
	?>
    <h3 style='color:green;'>Report of Date:<?php echo $date; ?></h3>
	<table border="1">
	<thead><th>Name</th><th>Sample number</th><th>Fat</th><th>Liters</th><th>Rate/liter</th><th>Price</th></thead>
	<tbody>
	<?php
	while($fetch=mysqli_fetch_array($list)){?>
	<tr><td><?php echo $fetch['name'];?></td>
	<td><?php echo $fetch['sample_no'];?></td>
	<td><?php echo $fetch['fat'];?></td>
	<td><?php echo $fetch['liters'];?></td>
	<td><?php echo $fetch['rate'];?></td>
	<?php
	$rate=$fetch['rate'];
	$liter=$fetch['liters'];
	$price=$rate*$liter;
	$tp=$tp+$price;
	?>
	<td><?php echo $price;?></td><tr>
	<?php		
	}
	?>
	<tr><td colspan="5" align="right"><b>Total</b></td><td><?php echo $tp; ?></td></tr>
	</tbody>
	</table>
<?php
}
?>
            </div>
        </div>
    </body>
	
<?php
include("footer.php");}
else{
	echo "Invalid User";
}
?>
</html>
