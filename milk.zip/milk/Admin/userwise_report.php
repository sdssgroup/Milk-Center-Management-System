<?php
include("sidebar.php");
if($_SESSION['user_type']=='Administrator'){
$sl1="select * from users where user_type='User'";
$list1= $conn->query($sl1);
?>
<title>Userwise Report</title>
<div class="container">
<fieldset style="width:50%; "><legend>Enter the details Person: </legend>
<form method="post" action="">
<table><tr><td><label>Person Name</label></td><td>:</td>
<td><select name="user_id"><?php
while($row=mysqli_fetch_array($list1)){
?>
<option value="<?php echo $row['user_id'];?>"><?php echo $row['name'];?></option>
<?php }
?>
</select></td></tr><tr>
<tr><td>From Date</td><td>:</td><td><input type="date" name="fdate"></td></tr>
<tr><td>To Date</td><td>:</td><td><input type="date" name="tdate"></td></tr>
<td colspan="3" align="center"><input type="submit" name="submit" value="OK"></td></tr>

</form></fieldset></table><br><br>
				<div>
                </div>
<?php
if(isset($_POST['submit'])){
	$user_id=$_POST['user_id'];
	$fdate=$_POST['fdate'];
	$tdate=$_POST['tdate'];
	$tp=0;
	$tl=0;
	$sl="select * from datewise_entry where user_id='$user_id' and date between '$fdate' and '$tdate' order by date";
	$list= $conn->query($sl);
	?>
    <h3 style='color:green;'>Report of User:<?php echo $user_id; ?></h3>
	<table border="1">
	<thead><th>Name</th><th>Date</th><th>Session</th><th>Sample number</th><th>Fat</th><th>Liters</th><th>Rate/liter</th><th>Price</th></thead>
	<tbody>
	<?php
	$count=mysqli_num_rows($list);
	while($fetch=mysqli_fetch_array($list)){
		if($count>0){?>
	<tr><td><?php echo $fetch['name'];?></td>
	<td><?php echo $fetch['date'];?></td>
	<td><?php echo $fetch['session'];?></td>
	<td><?php echo $fetch['sample_no'];?></td>
	<td><?php echo $fetch['fat'];?></td>
	<td><?php echo $fetch['liters'];?></td>
	<td>Rs. <?php echo $fetch['rate'];?></td>
	<?php
	$rate=$fetch['rate'];
	$liter=$fetch['liters'];
	$price=$rate*$liter;
	$tp=$tp+$price;
	$tl=$tl+$liter;
	?>
	<td>Rs. <?php echo $price;?></td><tr>
	<?php		
	}else{?>
		<td colspan="6">No record(s) found.</td>
	<?php }
	}
	?>
	<tr><td colspan="5" align="right"><b>Total</b></td><td><?php echo $tl; ?></td><td colspan="2">Rs. <?php echo $tp; ?></td></tr>
	</tbody>
	</table>
<?php
}
?>
            </div>
        </div>
    </body>
	
<?php
include("footer.php");
}else{
	echo "Invalid User";
}
?>
</html>
