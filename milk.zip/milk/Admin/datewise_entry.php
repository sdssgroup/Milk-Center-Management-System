<?php
$date=date('Y-m-d');
include("sidebar.php");
if($_SESSION['user_type']=='Administrator'){
?>
<title>Datewise Entry Form</title>
<div class="container">
<fieldset style="width:50%; "><legend>Enter the person details of date: <?php echo date('d-m-Y'); ?> </legend>
<form method="post" action="">
<table><tr><td><label>Date</label></td><td>:</td>
<td><input type="date" name="date" value="<?php echo date('Y-m-d'); ?>"></td></tr>
<tr><td><label>Username </label></td><td>:</td>
<td><select name="user_id" style="width:150px" required>
<option value="">Select one user</option>
							<?php $user_query="select * from users where user_type='User'";
                                  $user = $conn ->query($user_query);
									while($col=mysqli_fetch_array($user)){
									$id=$col['user_id']; ?>
				<option value="<?php echo $col['user_id']; ?>" ><?php echo $col['name']; ?></option>
									<?php }?>	
</select></td></tr>
<tr><td><label>Liters</label></td><td>:</td><td><input type="text" name="liters" placeholder="Liters"required></td></tr>
<tr><td><label>Milk Sample No.</label></td><td>:</td><td><input type="text" name="msno" placeholder="Milk Sample Number"required></td></tr>
<tr><td><label>Fat</label></td><td>:</td><td><input type="text" name="fat" placeholder="Fat" required></td></tr>
<tr><td><label>Milk Type</label></td><td>:</td><td><select name="milk_type">
<option value="Buffalo">Buffalo Milk</option>
<option value="Cow">Cow Milk</option>
</select></td></tr>
<tr><td><label>Rate/liter</label></td><td>:</td><td><input type="text" name="lrate" placeholder="Rate"></td></tr>
<tr><td><label>Session</label></td><td>:</td><td><select name="session"><option>Morning</option><option>Evening</option></select></td></tr>
<tr><td colspan="3" align="center"><input type="submit" name="submit" value="Insert"></td></tr>
</form></fieldset></table>
</html>
<?php
if(isset($_POST['submit'])){
	$date=$_POST['date'];
	$user_id=$_POST['user_id'];
	$milk_type=$_POST['milk_type'];
	$fat=$_POST['fat'];
	$msno=$_POST['msno'];
	$session=$_POST['session'];
	$liters=$_POST['liters'];
	$user_query="select * from users where user_type='User' and user_id='$user_id'";
	$user = $conn ->query($user_query);
	$col=mysqli_fetch_array($user);
	$name=$col['name'];
	if($milk_type=="Buffalo"){
		if($fat>12.0){
			$fat=12.0;
		}
	}elseif($milk_type=="Cow"){
		if($fat>5.0){
			$fat=5.0;
		}
	}else{
	}
	$rate_query="select * from data where fat='$fat' and milk_type='$milk_type'";
	$rate = $conn ->query($rate_query);
	$lrate=mysqli_fetch_array($rate);
	$exist="select * from datewise_entry where user_id='$user_id' and date='$date' and session='$session' and milk_type='$milk_type' and sample_no='$msno'";
	$existing = $conn ->query($exist);
	$status=mysqli_fetch_array($existing);
	$count=mysqli_num_rows($existing);
	$rate1=$lrate['rate'];
	if($count>0){
		echo "<h2 style='color:red; align:center;'>Already Inserted</h2>";
	}else{
	$sl="insert into datewise_entry (user_id,name,fat,rate,liters,sample_no,milk_type,session,date) values ('$user_id','$name','$fat','$rate1','$liters','$msno','$milk_type','$session','$date')";
	$list= $conn->query($sl);
	echo "<h3 style='color:green;'>Sucessfully Inserted</h3>";
	}
}
?>
</center>
<center>
<br><?php echo "<h3 style='color:green;'> Date:  ".$date."</h3>"; ?><br>
<table border="1" align="center">
<thead>
<tr><th>User ID</th>
<th>Name</th>
<th>Sample No.</th>
<th>Fat</th>
<th>Liters</th>
<th>Price/ltr</th>
<th>Session</th>
<th>Price</th></tr></thead>
<tbody>
<?php
	$tp=0;
	$tl=0;
	$tf=0;
	$n=0;
	$uprice=0;
	$avgfat=0;
	$sl="select * from datewise_entry where date='$date'";
	$list= $conn->query($sl);
while($fetch= mysqli_fetch_array($list)){
$id=$col['user_id'];?>

<tr><td><?php echo $fetch['user_id'];?></td>
<td><?php echo $fetch['name'];?></td>
<td><?php echo $fetch['sample_no'];?></td>
<td><?php echo $fetch['fat'];?></td>
<td><?php echo $fetch['liters'];?></td>
<td><?php echo $fetch['rate'];?></td>
<td><?php echo $fetch['session'];?>
<td>Rs. <?php $rate= $fetch['rate'];
$ltr= $fetch['liters'];
$n=$n+1;
$uprice=$ltr * $rate;
$tf= $tf+ $fetch['fat'];
echo $uprice;
$tp=$tp+$uprice;
$tl=$tl+$ltr;
 ?></td></td></tr>
<?php }
if($n=='0'){
}else{
$avgfat=$tf/$n;
}
?>
<tr><td colspan="3" align="right">Total </td><td><?php echo $avgfat;?><td><?php echo $tl;?> ltrs</td><td>Total</td><td colspan="2">Rs. <?php echo $tp;?></td></tr>
</tbody>
</table>
 </div>
            </div>
        </div>
    </body>
<?php
include("footer.php");
}else{
	echo "Invalid User";
}
?>
</html>
