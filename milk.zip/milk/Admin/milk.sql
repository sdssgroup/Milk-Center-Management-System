-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 05, 2020 at 01:38 PM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `milk`
--

-- --------------------------------------------------------

--
-- Table structure for table `advance`
--

CREATE TABLE `advance` (
  `id` int(11) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `need` text NOT NULL,
  `amount` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `transaction_type` varchar(255) NOT NULL,
  `date_applied` varchar(255) NOT NULL,
  `date_granted` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `advance`
--

INSERT INTO `advance` (`id`, `user_id`, `name`, `need`, `amount`, `status`, `transaction_type`, `date_applied`, `date_granted`) VALUES
(1, '4', 'PABBATHI SAI GIRISH 1', 'Test,\r\nTest,\r\nTest', '500', '', '', '2019-12-26', '');

-- --------------------------------------------------------

--
-- Table structure for table `bills`
--

CREATE TABLE `bills` (
  `id` int(11) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `liters` varchar(255) NOT NULL,
  `rate` varchar(255) NOT NULL,
  `advance` varchar(255) NOT NULL,
  `from_date` varchar(255) NOT NULL,
  `to_date` varchar(255) NOT NULL,
  `total_days` varchar(255) NOT NULL,
  `created_date` varchar(255) NOT NULL,
  `created_time` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bills`
--

INSERT INTO `bills` (`id`, `user_id`, `name`, `liters`, `rate`, `advance`, `from_date`, `to_date`, `total_days`, `created_date`, `created_time`) VALUES
(1, '4', 'PABBATHI SAI GIRISH', '20', '30', '', '2019-12-01', '2019-12-19', '18 days 0 months 00 years', '2019-12-21', ' 07:50:11');

-- --------------------------------------------------------

--
-- Table structure for table `bill_request`
--

CREATE TABLE `bill_request` (
  `id` int(11) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `month` varchar(255) NOT NULL,
  `year` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `date_requested` varchar(255) NOT NULL,
  `date_approved` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bill_request`
--

INSERT INTO `bill_request` (`id`, `user_id`, `name`, `month`, `year`, `status`, `date_requested`, `date_approved`) VALUES
(1, '4', 'PABBATHI SAI GIRISH 1', 'January', '2019', '', '2019-12-26', '');

-- --------------------------------------------------------

--
-- Table structure for table `change_password`
--

CREATE TABLE `change_password` (
  `id` int(11) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `old_password` varchar(255) NOT NULL,
  `new_password` varchar(255) NOT NULL,
  `date_changed` varchar(255) NOT NULL,
  `ip_address` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `change_password`
--

INSERT INTO `change_password` (`id`, `user_id`, `username`, `name`, `old_password`, `new_password`, `date_changed`, `ip_address`) VALUES
(1, '1', 'admin', 'PABBATHI SREESHAILAM', '1234', 'Sai@1234', '2019-12-25 00:05:17', '::1');

-- --------------------------------------------------------

--
-- Table structure for table `data`
--

CREATE TABLE `data` (
  `id` int(11) NOT NULL,
  `fat` varchar(255) NOT NULL,
  `rate` varchar(255) NOT NULL,
  `milk_type` varchar(255) NOT NULL,
  `date_modified` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `data`
--

INSERT INTO `data` (`id`, `fat`, `rate`, `milk_type`, `date_modified`) VALUES
(23, '0', '0', 'Buffalo', '05-01-2020 12:26:47'),
(24, '0.1', '0.56', 'Buffalo', '05-01-2020 12:26:47'),
(25, '0.2', '1.12', 'Buffalo', '05-01-2020 12:26:47'),
(26, '0.3', '1.6', 'Buffalo', '05-01-2020 12:26:47'),
(27, '0.4', '2.25', 'Buffalo', '05-01-2020 12:26:47'),
(28, '0.5', '2.82', 'Buffalo', '05-01-2020 12:26:47'),
(29, '0.6', '3.38', 'Buffalo', '05-01-2020 12:26:47'),
(30, '0.7', '3.94', 'Buffalo', '05-01-2020 12:26:47'),
(31, '0.8', '4.51', 'Buffalo', '05-01-2020 12:26:47'),
(32, '0.9', '5.07', 'Buffalo', '05-01-2020 12:26:47'),
(33, '1', '5.64', 'Buffalo', '05-01-2020 12:26:47'),
(34, '1.1', '6.20', 'Buffalo', '05-01-2020 12:26:47'),
(35, '1.2', '6.76', 'Buffalo', '05-01-2020 12:26:47'),
(36, '1.3', '7.33', 'Buffalo', '05-01-2020 12:26:47'),
(37, '1.4', '7.89', 'Buffalo', '05-01-2020 12:26:47'),
(38, '1.5', '8.46', 'Buffalo', '05-01-2020 12:26:47'),
(39, '1.6', '9.02', 'Buffalo', '05-01-2020 12:26:47'),
(40, '1.7', '9.58', 'Buffalo', '05-01-2020 12:26:47'),
(41, '1.8', '10.15', 'Buffalo', '05-01-2020 12:26:47'),
(42, '1.9', '10.71', 'Buffalo', '05-01-2020 12:26:47'),
(43, '2', '11.28', 'Buffalo', '05-01-2020 12:26:47'),
(44, '2.1', '11.84', 'Buffalo', '05-01-2020 12:26:47'),
(45, '2.2', '12.40', 'Buffalo', '05-01-2020 12:26:47'),
(46, '2.3', '12.97', 'Buffalo', '05-01-2020 12:26:47'),
(47, '2.4', '13.53', 'Buffalo', '05-01-2020 12:26:47'),
(48, '2.5', '14.1', 'Buffalo', '05-01-2020 12:26:47'),
(49, '2.6', '14.66', 'Buffalo', '05-01-2020 12:26:47'),
(50, '2.7', '15.22', 'Buffalo', '05-01-2020 12:26:47'),
(51, '2.8', '15.79', 'Buffalo', '05-01-2020 12:26:47'),
(52, '2.9', '16.35', 'Buffalo', '05-01-2020 12:26:47'),
(53, '3', '16.92', 'Buffalo', '05-01-2020 12:26:47'),
(54, '3.1', '17.48', 'Buffalo', '05-01-2020 12:26:47'),
(55, '3.2', '18.04', 'Buffalo', '05-01-2020 12:26:47'),
(56, '3.3', '18.61', 'Buffalo', '05-01-2020 12:26:47'),
(57, '3.4', '19.17', 'Buffalo', '05-01-2020 12:26:47'),
(58, '3.5', '19.74', 'Buffalo', '05-01-2020 12:26:47'),
(59, '3.6', '20.30', 'Buffalo', '05-01-2020 12:26:47'),
(60, '3.7', '20.86', 'Buffalo', '05-01-2020 12:26:47'),
(61, '3.8', '21.43', 'Buffalo', '05-01-2020 12:26:47'),
(62, '3.9', '21.99', 'Buffalo', '05-01-2020 12:26:47'),
(63, '4', '22.56', 'Buffalo', '05-01-2020 12:26:47'),
(64, '4.1', '23.12', 'Buffalo', '05-01-2020 12:26:47'),
(65, '4.2', '23.68', 'Buffalo', '05-01-2020 12:26:47'),
(66, '4.3', '24.25', 'Buffalo', '05-01-2020 12:26:47'),
(67, '4.4', '24.81', 'Buffalo', '05-01-2020 12:26:47'),
(68, '4.5', '25.38', 'Buffalo', '05-01-2020 12:26:47'),
(69, '4.6', '25.94', 'Buffalo', '05-01-2020 12:26:47'),
(70, '4.7', '26.50', 'Buffalo', '05-01-2020 12:26:47'),
(71, '4.8', '27.07', 'Buffalo', '05-01-2020 12:26:47'),
(72, '4.9', '27.63', 'Buffalo', '05-01-2020 12:26:47'),
(73, '5', '28.20', 'Buffalo', '05-01-2020 12:26:47'),
(74, '5.1', '28.73', 'Buffalo', '05-01-2020 12:26:47'),
(75, '5.2', '29.27', 'Buffalo', '05-01-2020 12:26:47'),
(76, '5.3', '29.80', 'Buffalo', '05-01-2020 12:26:47'),
(77, '5.4', '30.34', 'Buffalo', '05-01-2020 12:26:47'),
(78, '5.5', '30.87', 'Buffalo', '05-01-2020 12:26:47'),
(79, '5.6', '31.40', 'Buffalo', '05-01-2020 12:26:47'),
(80, '5.7', '31.94', 'Buffalo', '05-01-2020 12:26:47'),
(81, '5.8', '32.47', 'Buffalo', '05-01-2020 12:26:47'),
(82, '5.9', '33.01', 'Buffalo', '05-01-2020 12:26:47'),
(83, '6', '33.54', 'Buffalo', '05-01-2020 12:26:47'),
(84, '6.1', '34.07', 'Buffalo', '05-01-2020 12:26:47'),
(85, '6.2', '34.61', 'Buffalo', '05-01-2020 12:26:47'),
(86, '6.3', '35.14', 'Buffalo', '05-01-2020 12:26:47'),
(87, '6.4', '35.68', 'Buffalo', '05-01-2020 12:26:47'),
(88, '6.5', '36.21', 'Buffalo', '05-01-2020 12:26:47'),
(89, '6.6', '36.74', 'Buffalo', '05-01-2020 12:26:47'),
(90, '6.7', '37.28', 'Buffalo', '05-01-2020 12:26:47'),
(91, '6.8', '37.81', 'Buffalo', '05-01-2020 12:26:47'),
(92, '6.9', '38.35', 'Buffalo', '05-01-2020 12:26:47'),
(93, '7', '38.88', 'Buffalo', '05-01-2020 12:26:47'),
(94, '7.1', '39.41', 'Buffalo', '05-01-2020 12:26:47'),
(95, '7.2', '39.95', 'Buffalo', '05-01-2020 12:26:47'),
(96, '7.3', '40.48', 'Buffalo', '05-01-2020 12:26:47'),
(97, '7.4', '41.02', 'Buffalo', '05-01-2020 12:26:47'),
(98, '7.5', '41.55', 'Buffalo', '05-01-2020 12:26:47'),
(99, '7.6', '42.08', 'Buffalo', '05-01-2020 12:26:47'),
(100, '7.7', '42.62', 'Buffalo', '05-01-2020 12:26:47'),
(101, '7.8', '43.15', 'Buffalo', '05-01-2020 12:26:47'),
(102, '7.9', '43.69', 'Buffalo', '05-01-2020 12:26:47'),
(103, '8', '44.22', 'Buffalo', '05-01-2020 12:26:47'),
(104, '8.1', '44.75', 'Buffalo', '05-01-2020 12:26:47'),
(105, '8.2', '45.29', 'Buffalo', '05-01-2020 12:26:47'),
(106, '8.3', '45.82', 'Buffalo', '05-01-2020 12:26:47'),
(107, '8.4', '46.36', 'Buffalo', '05-01-2020 12:26:47'),
(108, '8.5', '46.89', 'Buffalo', '05-01-2020 12:26:47'),
(109, '8.6', '47.42', 'Buffalo', '05-01-2020 12:26:47'),
(110, '8.7', '47.96', 'Buffalo', '05-01-2020 12:26:47'),
(111, '8.8', '48.49', 'Buffalo', '05-01-2020 12:26:47'),
(112, '8.9', '49.03', 'Buffalo', '05-01-2020 12:26:47'),
(113, '9', '49.56', 'Buffalo', '05-01-2020 12:26:47'),
(114, '9.1', '50.09', 'Buffalo', '05-01-2020 12:26:47'),
(115, '9.2', '50.63', 'Buffalo', '05-01-2020 12:26:47'),
(116, '9.3', '51.16', 'Buffalo', '05-01-2020 12:26:47'),
(117, '9.4', '51.70', 'Buffalo', '05-01-2020 12:26:47'),
(118, '9.5', '52.23', 'Buffalo', '05-01-2020 12:26:47'),
(119, '9.6', '52.76', 'Buffalo', '05-01-2020 12:26:47'),
(120, '9.7', '53.20', 'Buffalo', '05-01-2020 12:26:47'),
(121, '9.8', '53.83', 'Buffalo', '05-01-2020 12:26:47'),
(122, '9.9', '54.37', 'Buffalo', '05-01-2020 12:26:47'),
(123, '10', '54.90', 'Buffalo', '05-01-2020 12:26:47'),
(124, '10.1', '55.43', 'Buffalo', '05-01-2020 12:26:47'),
(125, '10.2', '55.97', 'Buffalo', '05-01-2020 12:26:47'),
(126, '10.3', '56.50', 'Buffalo', '05-01-2020 12:26:47'),
(127, '10.4', '57.04', 'Buffalo', '05-01-2020 12:26:47'),
(128, '10.5', '57.57', 'Buffalo', '05-01-2020 12:26:47'),
(129, '10.6', '58.10', 'Buffalo', '05-01-2020 12:26:47'),
(130, '10.7', '58.64', 'Buffalo', '05-01-2020 12:26:47'),
(131, '10.8', '59.17', 'Buffalo', '05-01-2020 12:26:47'),
(132, '10.9', '59.71', 'Buffalo', '05-01-2020 12:26:47'),
(133, '11', '60.24', 'Buffalo', '05-01-2020 12:26:47'),
(134, '11.1', '60.77', 'Buffalo', '05-01-2020 12:26:47'),
(135, '11.2', '61.31', 'Buffalo', '05-01-2020 12:26:47'),
(136, '11.3', '61.84', 'Buffalo', '05-01-2020 12:26:47'),
(137, '11.4', '62.38', 'Buffalo', '05-01-2020 12:26:47'),
(138, '11.5', '62.91', 'Buffalo', '05-01-2020 12:26:47'),
(139, '11.6', '63.44', 'Buffalo', '05-01-2020 12:26:47'),
(140, '11.7', '63.98', 'Buffalo', '05-01-2020 12:26:47'),
(141, '11.8', '64.51', 'Buffalo', '05-01-2020 12:26:47'),
(142, '11.9', '65.05', 'Buffalo', '05-01-2020 12:26:47'),
(143, '12', '65.58', 'Buffalo', '05-01-2020 12:26:47'),
(144, '0', '0', 'Cow', '05-01-2020 12:26:47'),
(145, '0.1', '0.82', 'Cow', '05-01-2020 12:26:47'),
(146, '0.2', '1.64', 'Cow', '05-01-2020 12:26:47'),
(147, '0.3', '2.46', 'Cow', '05-01-2020 12:26:47'),
(148, '0.4', '3.28', 'Cow', '05-01-2020 12:26:47'),
(149, '0.5', '4.11', 'Cow', '05-01-2020 12:26:47'),
(150, '0.6', '4.93', 'Cow', '05-01-2020 12:26:47'),
(151, '0.7', '5.75', 'Cow', '05-01-2020 12:26:47'),
(152, '0.8', '6.57', 'Cow', '05-01-2020 12:26:47'),
(153, '0.9', '7.39', 'Cow', '05-01-2020 12:26:47'),
(154, '1', '8.22', 'Cow', '05-01-2020 12:26:47'),
(155, '1.1', '9.04', 'Cow', '05-01-2020 12:26:47'),
(156, '1.2', '9.86', 'Cow', '05-01-2020 12:26:47'),
(157, '1.3', '10.68', 'Cow', '05-01-2020 12:26:47'),
(158, '1.4', '11.50', 'Cow', '05-01-2020 12:26:47'),
(159, '1.5', '12.33', 'Cow', '05-01-2020 12:26:47'),
(160, '1.6', '13.15', 'Cow', '05-01-2020 12:26:47'),
(161, '1.7', '13.97', 'Cow', '05-01-2020 12:26:47'),
(162, '1.8', '14.79', 'Cow', '05-01-2020 12:26:47'),
(163, '1.9', '15.61', 'Cow', '05-01-2020 12:26:47'),
(164, '2', '16.44', 'Cow', '05-01-2020 12:26:47'),
(165, '2.1', '17.26', 'Cow', '05-01-2020 12:26:47'),
(166, '2.2', '18.08', 'Cow', '05-01-2020 12:26:47'),
(167, '2.3', '18.90', 'Cow', '05-01-2020 12:26:47'),
(168, '2.4', '19.72', 'Cow', '05-01-2020 12:26:47'),
(169, '2.5', '20.55', 'Cow', '05-01-2020 12:26:47'),
(170, '2.6', '21.37', 'Cow', '05-01-2020 12:26:47'),
(171, '2.7', '22.19', 'Cow', '05-01-2020 12:26:47'),
(172, '2.8', '23.01', 'Cow', '05-01-2020 12:26:47'),
(173, '2.9', '23.83', 'Cow', '05-01-2020 12:26:47'),
(174, '3', '24.66', 'Cow', '05-01-2020 12:26:47'),
(175, '3.1', '24.85', 'Cow', '05-01-2020 12:26:47'),
(176, '3.2', '25.05', 'Cow', '05-01-2020 12:26:47'),
(177, '3.3', '25.25', 'Cow', '05-01-2020 12:26:47'),
(178, '3.4', '25.44', 'Cow', '05-01-2020 12:26:47'),
(179, '3.5', '25.64', 'Cow', '05-01-2020 12:26:47'),
(180, '3.6', '25.84', 'Cow', '05-01-2020 12:26:47'),
(181, '3.7', '26.03', 'Cow', '05-01-2020 12:26:47'),
(182, '3.8', '26.23', 'Cow', '05-01-2020 12:26:47'),
(183, '3.9', '26.43', 'Cow', '05-01-2020 12:26:47'),
(184, '4', '26.63', 'Cow', '05-01-2020 12:26:47'),
(185, '4.1', '26.82', 'Cow', '05-01-2020 12:26:47'),
(186, '4.2', '27.02', 'Cow', '05-01-2020 12:26:47'),
(187, '4.3', '27.22', 'Cow', '05-01-2020 12:26:47'),
(188, '4.4', '27.41', 'Cow', '05-01-2020 12:26:47'),
(189, '4.5', '27.61', 'Cow', '05-01-2020 12:26:47'),
(190, '4.6', '27.81', 'Cow', '05-01-2020 12:26:47'),
(191, '4.7', '28.01', 'Cow', '05-01-2020 12:26:47'),
(192, '4.8', '28.21', 'Cow', '05-01-2020 12:26:47'),
(193, '4.9', '28.41', 'Cow', '05-01-2020 12:26:47'),
(194, '5', '30.0', 'Cow', '05-01-2020 12:26:47');

-- --------------------------------------------------------

--
-- Table structure for table `datewise_entry`
--

CREATE TABLE `datewise_entry` (
  `id` int(11) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `sample_no` varchar(255) NOT NULL,
  `milk_type` varchar(255) NOT NULL DEFAULT 'Buffalo',
  `liters` varchar(255) NOT NULL,
  `fat` varchar(255) NOT NULL,
  `rate` varchar(255) NOT NULL,
  `session` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `datewise_entry`
--

INSERT INTO `datewise_entry` (`id`, `user_id`, `name`, `sample_no`, `milk_type`, `liters`, `fat`, `rate`, `session`, `date`) VALUES
(1, '4', 'PABBATHI SAI GIRISH', '1', 'Buffalo', '10.0', '0.1', '1.5', 'Morning', '2019-12-19'),
(2, '4', 'PABBATHI SAI GIRISH', '1', 'Buffalo', '10.0', '0.1', '1.5', 'Evening', '2019-12-19'),
(3, '4', 'PABBATHI SAI GIRISH', '5', 'Buffalo', '20.0', '0.1', '1.5', 'Morning', '2019-12-20'),
(4, '4', 'PABBATHI SAI GIRISH', '1', 'Buffalo', '30.0', '0.1', '1.5', 'Evening', '2019-12-20'),
(5, '5', 'PABBATHI SHIVA SAI', '2', 'Buffalo', '5.0', '0.1', '1.5', 'Morning', '2019-12-20'),
(6, '4', 'PABBATHI SAI GIRISH', '4', 'Buffalo', '20.0', '0.1', '1.5', 'Morning', '2019-12-21'),
(7, '5', 'PABBATHI SHIVA SAI', '1', 'Buffalo', '2.0', '0.1', '1.5', 'Morning', '2019-12-21'),
(8, '4', 'PABBATHI SAI GIRISH', '5', 'Buffalo', '30.0', '12', '65.58', 'Morning', '2019-12-22'),
(9, '4', 'PABBATHI SAI GIRISH', '5', 'Buffalo', '30.0', '7.5', '41.55', 'Morning', '2019-12-23'),
(10, '5', 'PABBATHI SHIVA SAI', '6', 'Buffalo', '10.0', '9.2', '50.63', 'Morning', '2019-12-23'),
(11, '5', 'PABBATHI SHIVA SAI', '1', 'Buffalo', '20.0', '7.2', '39.95', 'Morning', '2019-12-26'),
(12, '4', 'PABBATHI SAI GIRISH 1', '1', 'Buffalo', '2', '12', '65.58', 'Morning', '2020-01-03'),
(13, '5', 'PABBATHI SHIVA SAI', '2', 'Buffalo', '2.5', '11', '60.24', 'Morning', '2020-01-03'),
(14, '6', 'PABBATHI SAI GIRISH', '3', 'Buffalo', '1.5', '7.5', '41.55', 'Morning', '2020-01-03'),
(15, '4', 'PABBATHI SAI GIRISH 1', '1', 'Buffalo', '12', '12', '65.58', 'Morning', '2020-01-02'),
(16, '5', 'PABBATHI SHIVA SAI', '2', 'Buffalo', '15', '10', '54.90', 'Morning', '2020-01-02'),
(17, '6', 'PABBATHI SAI GIRISH', '3', 'Buffalo', '16', '12', '65.58', 'Morning', '2020-01-02'),
(18, '4', 'PABBATHI SAI GIRISH 1', '55', 'Cow', '1.5', '5', '30.0', 'Evening', '2020-01-09'),
(19, '5', 'PABBATHI SHIVA SAI', '1585', 'Buffalo', '2', '12', '65.58', 'Evening', '2020-01-09'),
(20, '6', 'PABBATHI SAI GIRISH', '20', 'Buffalo', '15', '12', '65.58', 'Evening', '2020-01-09');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(11) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `feedback` text NOT NULL,
  `feedback_status` varchar(255) NOT NULL,
  `suggestion` text NOT NULL,
  `reply_to_suggestion` varchar(255) NOT NULL,
  `date_created` varchar(255) NOT NULL,
  `date_solved` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `user_id`, `name`, `feedback`, `feedback_status`, `suggestion`, `reply_to_suggestion`, `date_created`, `date_solved`) VALUES
(1, '5', 'PABBATHI SHIVA SAI', 'Awesome TEST!!', 'Not Solved', 'Improve to the better version of MMS 2.0', 'Test Case', '2019-01-03', '2020-01-04');

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int(11) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `file_location` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `created_date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `user_id`, `name`, `title`, `description`, `file_location`, `status`, `created_date`) VALUES
(1, '1', 'PABBATHI SREESHAILAM', 'Bills sanctioned for the months of November and December, 2019', 'test,\r\ntest\r\ntest\r\ntest\r\ntest\r\ntset\r\n', 'Bills sanctioned for the months of November and December, 2019.pdf', 'Active', '2019-12-26'),
(2, '1', 'PABBATHI SREESHAILAM', 'Hill Stational Message', 'Your luck Our success', 'Bills sanctioned for the months of November and December, 2019.pdf', 'Active', '2019-12-26'),
(3, '1', 'PABBATHI SREESHAILAM', 'December', '12', 'Bills sanctioned for the months of November and December, 2019.pdf', 'Active', '2019-12-26'),
(4, '1', 'PABBATHI SREESHAILAM', 'January,2020', '1', 'Bills sanctioned for the months of November and December, 2019.pdf', 'Active', '2019-12-26'),
(5, '1', 'PABBATHI SREESHAILAM', 'February,2020', '2\r\n', 'Bills sanctioned for the months of November and December, 2019.pdf', 'Active', '2019-12-26'),
(6, '1', 'PABBATHI SREESHAILAM', 'March,2020', '3', 'Bills sanctioned for the months of November and December, 2019.pdf', 'Active', '2019-12-26'),
(7, '1', 'PABBATHI SREESHAILAM', 'April,2020', '4', 'Bills sanctioned for the months of November and December, 2019.pdf', 'Active', '2019-12-26'),
(8, '1', 'PABBATHI SREESHAILAM', 'May,2020', '5', 'Bills sanctioned for the months of November and December, 2019.pdf', 'Active', '2019-12-26'),
(9, '1', 'PABBATHI SREESHAILAM', 'June,2020', '6', 'Bills sanctioned for the months of November and December, 2019.pdf', 'Active', '2019-12-26'),
(10, '1', 'PABBATHI SREESHAILAM', 'July,2020', '7\r\n', 'Bills sanctioned for the months of November and December, 2019.pdf', 'Active', '2019-12-26'),
(11, '1', 'PABBATHI SREESHAILAM', 'August,2020', '8', 'Bills sanctioned for the months of November and December, 2019.pdf', 'Active', '2019-12-26'),
(12, '1', 'PABBATHI SREESHAILAM', 'September,2020', '9', 'Bills sanctioned for the months of November and December, 2019.pdf', 'Active', '2019-12-26'),
(13, '1', 'PABBATHI SREESHAILAM', 'October,2020', '10', 'Bills sanctioned for the months of November and December, 2019.pdf', 'Active', '2019-12-26');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `text_wak` varchar(255) NOT NULL,
  `dob` varchar(255) NOT NULL,
  `father_name` varchar(255) NOT NULL,
  `aadhar_number` varchar(255) NOT NULL,
  `aadhar_pic` varchar(255) NOT NULL,
  `pan` varchar(255) NOT NULL,
  `bank_account_no` varchar(255) NOT NULL,
  `bank_passbook` varchar(255) NOT NULL,
  `ifsc` varchar(255) NOT NULL,
  `photo` varchar(255) NOT NULL,
  `sign` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `user_type` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `created_date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `name`, `password`, `text_wak`, `dob`, `father_name`, `aadhar_number`, `aadhar_pic`, `pan`, `bank_account_no`, `bank_passbook`, `ifsc`, `photo`, `sign`, `email`, `phone`, `user_type`, `status`, `created_date`) VALUES
(1, 'admin', 'PABBATHI SREESHAILAM', 'a4a1e4ad1643591ff2c041ff9167ff45', 'Sai@1234', '2001-06-22', '', '', '', '', '', '', '', '', '', '', '', 'Administrator', 'active', ''),
(4, 'psaigirish', 'PABBATHI SAI GIRISH 1', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(5, 'pshivasai', 'PABBATHI SHIVA SAI', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(6, 'user_sai', 'PABBATHI SAI GIRISH', '700d5d1ec3b46cadd22e59702f9a1491', '2001-06-22', '2001-06-22', 'PABBATHI SREESHAILAM', '417740367480', '', 'KIMPS5735N', '100110202004571', '', 'UTIB0SSUD03', '', '', 'Saigirishpabbathi.com@gmail.com', '9948164984', 'User', 'active', '2019-12-22 18:27:30');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `advance`
--
ALTER TABLE `advance`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bills`
--
ALTER TABLE `bills`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bill_request`
--
ALTER TABLE `bill_request`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `change_password`
--
ALTER TABLE `change_password`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `data`
--
ALTER TABLE `data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `datewise_entry`
--
ALTER TABLE `datewise_entry`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `advance`
--
ALTER TABLE `advance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `bills`
--
ALTER TABLE `bills`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `bill_request`
--
ALTER TABLE `bill_request`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `change_password`
--
ALTER TABLE `change_password`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `data`
--
ALTER TABLE `data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=195;

--
-- AUTO_INCREMENT for table `datewise_entry`
--
ALTER TABLE `datewise_entry`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
