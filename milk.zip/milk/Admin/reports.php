<?php
include("sidebar.php");
if($_SESSION['user_type']=='Administrator'){
?>
<title>Admin Reports</title>
<style>
a{
	color:black;
}
.li1{
	padding:10px;
}
</style>
<div class="container">
	<div class="card-content" style="height:auto;">
		<ul>
		<li class="li1"><a href="bill_generation_report_userwise.php" onclick="onLinkClick()">Bill Generation Report(Userwise) </a></li>
		<li class="li1"><a href="bill_generation_report_datewise.php" onclick="onLinkClick()">Bill Generation Report(Datewise) </a></li>
		<li class="li1"><a href="datewise_entry_report.php" onclick="onLinkClick()"> Datewise Report </a></li>
		<li class="li1"><a href="userwise_report.php" onclick="onLinkClick()"> Userwise Report </a></li>
		<li class="li1"><a href="view_feedback.php" onclick="onLinkClick()"> Feedback Report</a></li>
		<li class="li1"><a href="view_contact_us.php" onclick="onLinkClick()"> Contact Us Report </a></li>
		<li class="li1"><a href="news_report">News Report</a></li>
		<li class="li1"><a href="change_password_report.php">Change Password Report</a></li>
		<li class="li1"><a href="datewise_entry_all_users.php">All user entry</a></li>
		</ul>
	</div>
</div>
</div>
</div>          
</div>
</body>
</html>
<?php
include("footer.php");
}else{
	echo "Invalid User";
}
?>