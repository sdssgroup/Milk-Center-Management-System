<?php
$conn=mysqli_connect("localhost","root","","milk");
date_default_timezone_set('Asia/Kolkata');
?>