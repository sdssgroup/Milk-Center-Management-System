<?php
include("sidebar.php");
if($_SESSION['user_type']=='Administrator'){
	$date_filter=date('Y-m-d');
?>
<title>Feedback</title>
<div class="container">
<table border="1" width="75%">
<thead><form method="get" action="">
<tr style="background:rgb(50,50,210)" align="center"><td colspan="4"><input type="date" name="filter_date" value="<?php echo date('Y-m-d');?>"></td><td colspan="4"><input type="submit" name="filter" ></td></tr>
</form><tr><th>User ID</th><th>Name</th><th>Feedback</th><th>Suggestion</th><th>Reply</th><th>Complaint Date</th><th>Solved Date</th><th>Edit</th></tr></thead>
<tbody>
<?php
$date_filter='';
if(isset($_GET['filter'])){
$date_filter=$_GET['filter_date'];
}
if($date_filter!=''){
$fb_sql="select * from feedback where date_solved='$date_filter'";
$fb_results=$conn->query($fb_sql);
while($fb_row=mysqli_fetch_array($fb_results)){
?><tr>
<td><?php echo $fb_row['user_id']; ?></td>
<td><?php echo $fb_row['name']; ?></td>
<td><?php echo $fb_row['feedback']; ?></td>
<td><?php echo $fb_row['suggestion']; ?></td>
<td><?php echo $fb_row['reply_to_suggestion']; ?></td>
<td><?php echo $fb_row['date_created']; ?></td>
<td><?php echo $fb_row['date_solved']; ?></td>
<td><a href="edit_feedback.php?id=<?php echo $fb_row['id']?>">Edit</a></td>
</tr>
<?php
}}
else{
$fb_sql="select * from feedback where date_solved=''";
$fb_results=$conn->query($fb_sql);
while($fb_row=mysqli_fetch_array($fb_results)){
?><tr>
<td><?php echo $fb_row['user_id']; ?></td>
<td><?php echo $fb_row['name']; ?></td>
<td><?php echo $fb_row['feedback']; ?></td>
<td><?php echo $fb_row['suggestion']; ?></td>
<td><?php echo $fb_row['reply_to_suggestion']; ?></td>
<td><?php echo $fb_row['date_created']; ?></td>
<td><?php echo $fb_row['date_solved']; ?></td>
<td><a href="edit_feedback.php?id=<?php echo $fb_row['id']?>">Edit</a></td>
</tr>
<?php
}}
?>
</tbody>
</table>
</div>
            </div>
        </div>
</body>
</html>
<?php
include("footer.php");
}else{
	echo "Invalid User";
}
?>