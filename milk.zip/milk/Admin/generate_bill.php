<?php
include("sidebar.php");
if($_SESSION['user_type']=='Administrator'){
$sl1="select * from users where user_type='User'";
$list1= $conn->query($sl1);
?>
<title>Bill Generation</title>
<div class="container">
<fieldset style="width:50%; "><legend>Enter the details Person: </legend>
<form method="post" action="">
<table>
<tr><td>Username</td><td>:</td><td><select name="user_id" required>
<option value="">Select one user</option>
<?php
while($row=mysqli_fetch_array($list1)){?>
<option value="<?php echo $row['user_id']; ?>"><?php echo $row['name'];?></option>
<?php	
}
?></select></td></tr>
<tr><td>From date</td><td>:</td><td><input type="date" name="fdate" required></td></tr>
<tr><td>To date</td><td>:</td><td><input type="date" name="tdate" required></td></tr>
<tr><td>Bill Generation Key</td><td>:</td><td><input type="password" name="bgk" required></td></tr>
<tr><td></td><td><input type="submit" name="submit" value="generate"></td><td></td></tr>
</table>
</form>
</fieldset>
<?php
if(isset($_POST['submit'])){
	$user_id=$_POST['user_id'];
	$fdate=$_POST['fdate'];
	$tdate=$_POST['tdate'];
	$bgk=$_POST['bgk'];
	$tdays1=date_diff(date_create($fdate), date_create($tdate));
	$tdays=$tdays1->format('%d days %m months %Y years');
	$created_date=date("Y-m-d");
	$created_time=date("H:i:s");
	if($fdate=='' && $tdate=='' && $user=='' && $bgk==''){
		echo "Please fill all required fields."; 
	}elseif($fdate>$tdate){
		echo "Please enter From date less than To date";
	}elseif($bgk!=date("mY")){
		echo "Invalid Bill generation Key";
	}else{
	$user_id=$_POST['user_id'];
	$tp=0;
	$tl=0;
	$sl="select * from datewise_entry where user_id='$user_id' and date between '$fdate' and '$tdate' order by date";
	$list= $conn->query($sl);
	?>
	<table border="1">
	<thead><th>Name</th><th>Date</th><th>Session</th><th>Sample number</th><th>Fat</th><th>Liters</th><th>Rate/liter</th><th>Price</th></thead>
	<tbody>
	<?php
	$count=mysqli_num_rows($list);
	while($fetch=mysqli_fetch_array($list)){
			$name=$fetch['name'];?>
	<tr><td><?php echo $fetch['name'];?></td>
	<td><?php echo $fetch['date'];?></td>
	<td><?php echo $fetch['session'];?></td>
	<td><?php echo $fetch['sample_no'];?></td>
	<td><?php echo $fetch['fat'];?></td>
	<td><?php echo $fetch['liters'];?></td>
	<td>Rs. <?php echo $fetch['rate'];?></td>
	<?php
	$rate=$fetch['rate'];
	$liter=$fetch['liters'];
	$price=$rate*$liter;
	$tp=$tp+$price;
	$tl=$tl+$liter;
	?>
	<td>Rs. <?php echo $price;?></td></tr>
	<?php
	}
	?>
	<tr><td colspan="5" align="right"><b>Total</b></td><td><?php echo $tl; ?></td><td colspan="2">Rs. <?php echo $tp; ?></td></tr>
	</tbody>
	</table>
	<?php
	$bill_sql="select * from bills where user_id='$user_id' and (from_date between '$fdate' and '$tdate') and (to_date between '$fdate' and '$tdate')";
	$bill_exist=$conn->query($bill_sql);
	$bill_count=mysqli_num_rows($bill_exist);
	$bill_array=mysqli_fetch_array($bill_exist);
	if($bill_count>0){
		echo "Bill already Generated.";
	//}elseif($fetch['name']==''){
		//echo "No records found with data provided.";
	}else{
	$sql1= "insert into bills (user_id,name,liters,rate,from_date,to_date,total_days,created_date,created_time) values('$user_id','$name','$tl','$tp','$fdate','$tdate','$tdays','$created_date','$created_time') ";
	$take=$conn->query($sql1);
	if($take){
		echo "Bill generated sucessfully";
	}else{
		echo "Failed to insert contact developer";
	}
	}
	
}
}
?>
            </div>
        </div>
    </body>
	
<?php
include("footer.php");
}else{
	echo "Invalid User";
}
?>
</html>
