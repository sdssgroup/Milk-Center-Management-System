<?php
include("sidebar.php");
if($_SESSION['user_type']=='Administrator'){
?>
<title>Grant Advance</title>
<div class="container">
<form method="post" action="">
<table border="1" width="75%">
<?php
$fb_sql="select * from advance where id='".mysqli_real_escape_string($conn,$_GET['id'])."'";
$fb_results=$conn->query($fb_sql);
$fb_row=mysqli_fetch_array($fb_results)
$feedback_id=mysqli_real_escape_string($conn,$_GET['id']);
$date_solved=date('Y-m-d');
$fb_query=mysqli_query($conn,"update advance set status='Granted', date_solved='$date_solved' where id='$feedback_id'");
if($fb_query){
	echo "<h1 style='color:rgb(20,200,20)'>Advance Granted Sucessfully</h1>";
}

?>
<script>window.location("view_advance_requests.php");</script>
</table>
</form>
</div>
            </div>
        </div>
</body>
</html>
<?php
include("footer.php");
}else{
	echo "Invalid User";
}
?>