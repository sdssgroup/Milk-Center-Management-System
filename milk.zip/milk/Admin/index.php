<?php
require_once('connect_db.php');
session_start();
if(isset($_SESSION['user_type']) && $_SESSION['user_type']!=""){
	if($_SESSION['user_type']=="Administrator"){
		header('location: ../Admin/dashboard.php');
	}elseif($_SESSION['user_type']=="User"){
		header('location:../user/dashboard.php');
	}elseif($_SESSION['user_type']=="Management"){
		header('location:../Management/dashboard.php');
	}else{
		echo "Invalid User";
	}
}
?>
<center>
<title>Login Page</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body, html {
  height: 100%;
  font-family: Arial, Helvetica, sans-serif;
}

* {
  box-sizing: border-box;
}

.bg-img {
  /* The image used */
  background-image: url("../images/img_nature.jpg");

  min-height: 480px;

  /* Center and scale the image nicely */
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
  position: relative;
}

/* Add styles to the form container */
.container {
  position: absolute;
  right: 0;
  margin: 20px;
  max-width: 300px;
  padding: 16px;
  background-color: white;
}

/* Full-width input fields */
input[type=text], input[type=password],select {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  border: none;
  background: #f1f1f1;
}

input[type=text]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

/* Set a style for the submit button */
.btn {
  background-color: #4CAF50;
  color: white;
  padding: 16px 20px;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

.btn:hover {
  opacity: 1;
}
</style>
<body style="padding:20px 80px 20px 80px;align:center; ">
<table width="100%"><tr><td colspan="3"><p style="text-shadow:1px 1px 1px rgba(255,163,240,1);font-weight:bold;color:#2A1FC2;background-color: ;border: 5px groove #f7b3e5;letter-spacing:2pt;word-spacing:4pt;font-size:50px;text-align:center;font-family:georgia, serif;line-height:1;width:100%;">
MILK CO-OPERATION OF TELANGANA STATE
	</p></td></tr>
<tr><td><p style="text-shadow:1px 1px 1px rgba(255,163,240,1);font-weight:bold;color:#2A1FC2;background-color: ;border: 5px groove #f7b3e5;letter-spacing:2pt;word-spacing:4pt;font-size:25px;text-align:center;font-family:georgia, serif;line-height:1;width:100%;">
Village: KADAPARTHY
	</p></td>
<td><p style="text-shadow:1px 1px 1px rgba(255,163,240,1);font-weight:bold;color:#2A1FC2;background-color: ;border: 5px groove #f7b3e5;letter-spacing:2pt;word-spacing:4pt;font-size:25px;text-align:center;font-family:georgia, serif;line-height:1;width:100%;">
Mandal: NAKREKAL
	</p></td>
<td><p style="text-shadow:1px 1px 1px rgba(255,163,240,1);font-weight:bold;color:#2A1FC2;background-color: ;border: 5px groove #f7b3e5;letter-spacing:2pt;word-spacing:4pt;font-size:25px;text-align:center;font-family:georgia, serif;line-height:1;width:100%;">
District: NALGONDA
	</p></td></tr>
	<tr height="20px"></tr>
</table>
</center>
<div class="bg-img">
  <form action="" class="container" method="post">
    <h1>Login</h1>

    <label for="email"><b>Username</b></label>
    <input type="text" placeholder="Enter Username" name="username" required>

    <label for="psw"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="password" required>
	
	<label for="utype"><b>User type</b></label><br>
      <select name="user_type" style="">
	  <option>Management</option>
	  <option>Administrator</option>
	  <option>User</option>
	  </select>
    <button type="submit" name="submit" class="btn">Login</button>
  </form>
</div><br><br><br>
<center>
<?php
include("footer.php");
?>
<?php
if(isset($_POST['submit'])){
	$username=$_POST['username'];
	$password=md5($_POST['password']);
	$user_type=$_POST['user_type'];
	if($user_type=="Administrator"){
		$sql="select * from users where username='$username' and password='$password' and user_type='Administrator'";
		$query=$conn->query($sql);
		$count=mysqli_num_rows($query);
		$row=mysqli_fetch_array($query);
		if($count>0){
			$_SESSION['id']=$row['user_id'];
			$_SESSION['username']=$row['username'];
			$_SESSION['user_type']=$row['user_type'];
			echo "<script>window.location='../Admin/dashboard.php'</script>";
		}else{
			echo "<script>alert('Proxy Login. Alert sent to Administrator.')</script>";
			}
	}elseif($user_type=="User"){
		$sql="select * from users where username='$username' and password='$password' and user_type='User' LIMIT 1";
		$query=$conn->query($sql);
		$count=mysqli_num_rows($query);
		$row=mysqli_fetch_array($query);
		if($count>0){
			$_SESSION['id']=$row['user_id'];
			$_SESSION['username']=$row['username'];
			$_SESSION['user_type']=$row['user_type'];
			echo "<script>window.location='../user/dashboard.php'</script>";
		}else{
			echo "<script>alert('Proxy Login. Alert sent to Administrator.')</script>";
			}
	}elseif($user_type=='Management'){
		$sql="select * from users where username='$username' and password='$password' and user_type='Management' LIMIT 1";
		$query=$conn->query($sql);
		$count=mysqli_num_rows($query);
		$row=mysqli_fetch_array($query);
		if($count>0){
			$_SESSION['id']=$row['user_id'];
			$_SESSION['username']=$row['username'];
			$_SESSION['user_type']=$row['user_type'];
			echo "<script>window.location='../Management/dashboard.php'</script>";
		}else{
			echo "<script>alert('Proxy Login. Alert sent to Administrator.')</script>";
			}
	}
}
?>
