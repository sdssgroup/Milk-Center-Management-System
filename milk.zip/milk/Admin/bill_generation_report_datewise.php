<?php
$date=date('Y-m-d');
include("sidebar.php");
if($_SESSION['user_type']=='Administrator'){
?>
<title>Datewise bill Generation Report</title>
<div class="container">
<fieldset style="width:50%; "><legend>Enter the details of date: <?php echo $date; ?> </legend>
<form method="post" action="">
<table><tr><td><label>Date</label></td><td>:</td>
<td><input type="date" name="date" value="<?php echo date('Y-m-d'); ?>"></td>
<td colspan="3" align="center"><input type="submit" name="submit" value="OK"></td></tr>
</form></fieldset></table><br><br>
				<div>
                </div>
<?php
if(isset($_POST['submit'])){
	$date=$_POST['date'];
	$tp=0;
	$sl="select * from bills where created_date='$date'";
	$list= $conn->query($sl);
	?>
    <h3 style='color:green;'>Report of Date:<?php echo $date; ?></h3>
	<table border="1">
	<thead><th>Name</th><th>Generated Date</th><th>Liters</th><th>Rate/liter</th><th>Price</th><th>Total days</th></thead>
	<tbody>
	<?php
	while($fetch=mysqli_fetch_array($list)){?>
	<tr><td><?php echo $fetch['name'];?></td>
	<td><?php echo $fetch['created_date'];?></td>
	<td><?php echo $fetch['liters'];?></td>
	<td><?php echo $fetch['rate'];?></td>
	<?php
	$rate=$fetch['rate'];
	$liter=$fetch['liters'];
	$price=$rate;
	$tp=$tp+$price;
	?>
	<td><?php echo $price;?></td>
	<td><?php echo $fetch['total_days'];?></td>
<tr>
	<?php		
	}
	?>
	<tr><td colspan="4" align="right"><b>Total</b></td><td align="center" colspan="2"><?php echo $tp; ?></td></tr>
	</tbody>
	</table>
<?php
}
?>
            </div>
        </div>
    </body>
	
<?php
include("footer.php");
}else{
	echo "Invalid User";
}
?>
</html>
