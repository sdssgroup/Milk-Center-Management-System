<?php
include("sidebar.php");
if($_SESSION['user_type']=='Administrator'){
?>
<title>User Registration</title>
<div class="container">
<form method="POST" action="">
<table width="100%">
<tr><td>Name</td><td>:</td><td><input type="text" placeholder="Name" name="name" required></td></tr>
<tr><td>Father Name</td><td>:</td><td><input type="text" placeholder="Father Name" name="fname" required></td></tr>
<tr><td>Mobile No.</td><td>:</td><td><input type="number" placeholder="Mobile Number" name="phone" required></td></tr>
<tr><td>Email</td><td>:</td><td><input type="email" placeholder="Email" name="email"></td></tr>
<tr><td>Date of Birth</td><td>:</td><td width=""><input type="date" placeholder="Date of Birth" name="dob" required></td></tr>
<tr><td>Bank Account No.</td><td>:</td><td><input type="password" placeholder="Bank Account Number" name="bank_account" required></td></tr>
<tr><td>Confirm Bank Account No.</td><td>:</td><td><input type="text" placeholder="Confirm Bank Account Number" name="confirm_bank_account" required></td></tr>
<tr><td>IFSC code</td><td>:</td><td><input type="text" placeholder="IFSC Code" name="ifsc" required></td></tr>
<tr><td>PAN Card No.</td><td>:</td><td><input type="text" name="pan" placeholder="PAN Card No." required></td></tr>
<tr><td>Aadhar Card No.</td><td>:</td><td><input type="number" name="aadhar_no" placeholder="Aadhar Number" required></td></tr>
<tr><td>Username</td><td>:</td><td><input type="text" placeholder="Username" name="username" required></td></tr>
<tr><td>Usertype</td><td>:</td><td><select name="user_type"><option>User</option><option>Administrator</option><option>Management</option></select></td></tr>
<tr><td colspan="3" align="center"><input type="submit" Value="Create User" name="submit"></td></tr>
</table>
</form>

<?php
if(isset($_POST['submit'])){
	$name=$_POST['name'];
	$fname=$_POST['fname'];
	$phone=$_POST['phone'];
	$email=$_POST['email'];
	$dob=$_POST['dob'];
	$password=md5($dob);
	$bank_account=$_POST['bank_account'];
	$confirm_bank_account=$_POST['confirm_bank_account'];
	$ifsc=$_POST['ifsc'];
	$aadhar_no=$_POST['aadhar_no'];
	$pan=$_POST['pan'];
	$username=$_POST['username'];
	$user_type=$_POST['user_type'];
	$created_date=date("Y-m-d H:i:s");
	if($name==''||$fname==''||$phone==''||$dob==''||$bank_account==''||$confirm_bank_account==''||$ifsc==''||$aadhar_no==''||$username==''||$user_type==''){
		echo "Please enter all required fields.";
	}elseif($bank_account!=$confirm_bank_account){
		echo "Bank Accounts does not match";
	}else{
		$sql="select * from users where username='$username' or phone='$phone' or aadhar_number='$aadhar_no'";
		$query=$conn->query($sql);
		$count=mysqli_num_rows($query);
		if($count>0){
			echo "Username/Phone/aadhar_no/email exists already please choose another details.";
		}else{
			$sql1="insert into users (name,username,father_name,phone,email,dob,bank_account_no,ifsc,aadhar_number,pan,user_type,password,text_wak,created_date) 
			values('$name','$username','$fname','$phone','$email','$dob','$bank_account','$ifsc','$aadhar_no','$pan','$user_type','$password','$dob','$created_date')";
			$query1=$conn->query($sql1);
			if($query1){
				echo "User Account has been successfully created with username=".$username.".";
			}else{
				echo "Something went wrong contact developer.";
			}
		}
	}
}
?>
 </div>
            </div>
        </div>
		
    </body>
<?php
include("footer.php");
}else{
	echo "Invalid User";
}
?>
</html>