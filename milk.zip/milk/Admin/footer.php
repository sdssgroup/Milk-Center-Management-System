<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
.footer {
   left: 0;
   bottom: 0;
   width: 89%;
   background-color: #101010;
   color: white;
   text-align: center;
}
</style>
</head>
<body>
<div class="footer" style="padding:10px 80px 10px 80px;">
  <h4>Copyright &copy; <?php echo date('Y')?>. All rights are reserved. Designed and Developed by Pabbathi Sai Girish.</h4>
</div>

</body>
</html> 
