<?php
include("sidebar.php");
if($_SESSION['user_type']=='Administrator'){
?>
<title>Post News Feed</title>
<div class="container">
<fieldset style="width:50%; "><legend>Enter the Post details: <?php echo date('d-m-Y'); ?> </legend>
<form action="" enctype="multipart/form-data" method="post">
<table>
<tr><td>Title</td><td> :</td><td><input type="text" name="title" required><br/></td></tr>
<tr><td>Description</td><td> :</td><td><textarea id="description" name="description" required></textarea><br/></td></tr>
<tr><td>Attach file </td><td>:</td><td><input type="file" name="file" required><br/></td></tr>
<tr><td>Status</td><td>:</td><td><select name="status" required><option></option><option>Active</option><option>Not Active</option></select></td></tr>
<tr><td>Username</td><td> :</td><td><input type="text" name="username" value="<?php echo $_SESSION['username']?>"><br/></td></tr>
<tr><td>Name</td><td> :</td><td><input type="text" name="username" value="<?php echo $row['name']?>"><br/></td></tr>
<tr><td colspan="3" align="center"><input type="submit" value="Upload" name="Submit"></td></tr>
</table>
</form>
 

<?php
if(isset($_POST['Submit']))
{ 
$username=$_SESSION['username'];
$name1=$row['name'];
$user_id=$_SESSION['id'];
$extension = pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION);
$title = $_POST["title"];
$status = $_POST["status"];
$description = $_POST["description"];
$date=date('Y-m-d');
$name = $_POST["title"].".".$extension;
$size=$_FILES["file"]["size"];
$ext=".".$extension;
$allowed_file_types = array('.jpeg','.jpg','.png','.pdf');
if($username=='' && $user_id=='' && $status=='' && $title=='' && $description=='' && $status=='' && $name1==''){
	echo "Please fill all required fields";
}elseif($size>5000000){
	echo "Attachment file is too large";
}elseif(in_array($ext,$allowed_file_types)){
	if(file_exists("../uploads/" . $name)){
		echo "<h1 style='color:red; align:center'>Already inserted</h1>";
	}else{
	move_uploaded_file($_FILES["file"]["tmp_name"],"../uploads/". $name);
	$news="insert into news (user_id,name,title,description,file_location,status,created_date)
	values('$user_id','$name1','$title','$description','$name','$status','$date')";
	$news_query=$conn->query($news);
	if($news_query){
		echo "Successfully news posted";
	}else{
		echo "Failed to insert contact developer";
	}
	}
}else{
	echo "Invalid File type";
}
}
?>
</fieldset></div>
            </div>
        </div>
</body>
</html>
<?php
include("footer.php");
}else{
	echo "Invalid User";
}
?>