<?php
include("sidebar.php");
if($_SESSION['user_type']=='Administrator'){
	$date_filter=date('Y-m-d');
?>
<title>Bill Requests</title>
<div class="container">
<table border="1" width="75%">
<thead><form method="get" action="">
<tr style="background:rgb(50,50,210)" align="center"><td colspan="5"><input type="date" name="filter_date" value="<?php echo date('Y-m-d');?>"></td><td colspan="4"><input type="submit" name="filter" ></td></tr>
</form><tr><th>User ID</th><th>Name</th><th>Month</th><th>Year</th><th>Status</th><th>Applied Date</th><th>Approved Date</th><th>Delete</th><th>Grant</th></tr></thead>
<tbody>
<?php
$date_filter='';
if(isset($_GET['filter'])){
$date_filter=$_GET['filter_date'];
}
if($date_filter!=''){
$fb_sql="select * from bill_request where date_approved='$date_filter'";
$fb_results=$conn->query($fb_sql);
while($fb_row=mysqli_fetch_array($fb_results)){
?><tr>
<td><?php echo $fb_row['user_id']; ?></td>
<td><?php echo $fb_row['name']; ?></td>
<td><?php echo $fb_row['month']; ?></td>
<td><?php echo $fb_row['year']; ?></td>
<td><?php echo $fb_row['status']; ?></td>
<td><?php echo $fb_row['date_requested']; ?></td>
<td><?php echo $fb_row['date_approved']; ?></td>
<td height="30px" align="center"><a style="background:red; padding:2px; width:15px; text:bold; color:white" href="reject_advance_requests.php?id=<?php echo $fb_row['id']?>">Reject</a></td>
<td  height="30px" align="center"><a style="background:rgb(50,200,50); padding:2px; width:15px; text:bold; color:white" href="grant_advance_requests.php?id=<?php echo $fb_row['id']?>">Grant</a></td>
</tr>
<?php
}}
?>
</tbody>
</table>
</div>
            </div>
        </div>
</body>
</html>
<?php
include("footer.php");
}else{
	echo "Invalid User";
}
?>