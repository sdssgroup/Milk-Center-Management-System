<?php
include("sidebar.php");
if($_SESSION['user_type']=='Administrator'){
?>
<title>Edit Ratelist</title>
<div class="container">
<form method="POST" action="">
<table border="1" width="80%" style="text-align:center">
<thead><th><button onclick="history.go(-2)">Go back</button></th>
<th colspan="3" align="center"><font size="6">Details of Fat</font></th></tr>
<tr><th>S. No.</th>
<th>Fat(per liter)</th>
<th>Rate(in rupees)*</th>
<th>Milk Type</th></tr>
</thead>
<?php
$query="select * from data ORDER BY ID";
$dash = $conn	 ->query($query);
$count=0;
while($row=mysqli_fetch_array($dash)){
$id=$row['id'];
$count=$count+1;?>
<tr><td><?php echo $count;?></td>
<td><input type="text" name="fat[]" value="<?php echo $row['fat'];?>" readonly></td>
<td><input type="text" name="rate[]" value="<?php echo $row['rate'];?>"></td>
<td><input type="text" name="milk_type[]" value="<?php echo $row['milk_type'];?>" readonly></td></tr>
<?php }
?>
<tr><td colspan="4"><input type="submit" name="submit" value="Submit"></td></tr>
</table></form>
 </div>
            </div>
        </div>
		
    </body>

<?php
include("footer.php");
?>
</html>

<?php
if(isset($_POST['submit'])){
	$date_modified=date("d-m-Y H:i:s");
	for($i=0;$i<$count;$i++){
		$sql="update data set rate='".$_POST['rate'][$i]."', date_modified='$date_modified' where milk_type='".$_POST['milk_type'][$i]."' and fat='".$_POST['fat'][$i]."'";
		$sq= mysqli_query($conn,$sql);
	}
	$sql=rtrim($sql,",");
	if($sq){
		echo "<h1 color='green'>Data Update Success</h1>";
	}else{
		echo "Updation Failed";
	}
}
}else{
	echo "Invalid User";
}
?>
