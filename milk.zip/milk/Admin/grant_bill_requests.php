<?php
include("sidebar.php");
if($_SESSION['user_type']=='Administrator'){
?>
<title>Grant Advance</title>
<div class="container">
<form method="post" action="">
<?php
$feedback_id=mysqli_real_escape_string($conn,$_GET['id']);
$fb_sql="select * from advance where id='$feedback_id'";
$fb_results=$conn->query($fb_sql);
$fb_row=mysqli_fetch_array($fb_results);
$date_solved=date('Y-m-d');
$feedback_id=mysqli_real_escape_string($conn,$_GET['id']);
$fb_query=mysqli_query($conn,"update advance set status='Granted', transaction_type='Cash', date_granted='$date_solved' where id='$feedback_id'");
if($fb_query){
	echo "<script>alert('Bill Granted Sucessfully');</script>";
}
?>
<script>window.location="bill_requests.php";</script>
</form>
</div>
            </div>
        </div>
</body>
</html>
<?php
include("footer.php");
}else{
	echo "Invalid User";
}
?>