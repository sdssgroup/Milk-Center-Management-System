<?php
include("sidebar.php");
if($_SESSION['user_type']=='Administrator'){
$sl1="select * from users where user_type='User'";
$list1= $conn->query($sl1);
?>
<title>Userwise bill Generation Report</title>
<div class="container">
<fieldset style="width:50%; "><legend>Enter the details Person: </legend>
<form method="post" action="">
<table><tr><td><label>Person Name</label></td><td>:</td>
<td><select name="user_id"><?php
while($row=mysqli_fetch_array($list1)){
?>
<option value="<?php echo $row['user_id'];?>"><?php echo $row['name'];?></option>
<?php }
?>
</select></td></tr><tr>
<td colspan="3" align="center"><input type="submit" name="submit" value="OK"></td></tr>

</form></fieldset></table><br><br>
				<div>
                </div>
<?php
if(isset($_POST['submit'])){
	$user_id=$_POST['user_id'];
	$tp=0;
	$tl=0;
	$sl="select * from bills where user_id='$user_id' order by created_date";
	$list= $conn->query($sl);
	?>
    <h3 style='color:green;'>Report of User:<?php echo $user_id; ?></h3>
	<table border="1">
	<thead><th>Name</th><th>Generated Date</th><th>Liters</th><th>Price</th><th>From Date</th><th>To Date</th><th>Total Days</th></thead>
	<tbody>
	<?php
	$count=mysqli_num_rows($list);
	while($fetch=mysqli_fetch_array($list)){
		if($count>0){?>
	<tr><td><?php echo $fetch['name'];?></td>
	<td><?php echo $fetch['created_date'];?></td>
	<td><?php echo $fetch['liters'];?></td>
	<td>Rs. <?php echo $fetch['rate'];?></td>
	<td><?php echo $fetch['from_date'];?></td>
	<td><?php echo $fetch['to_date'];?></td>
	<td><?php echo $fetch['total_days'];?></td>
	<?php
	$rate=$fetch['rate'];
	$liter=$fetch['liters'];
	$tp=$tp+$rate;
	$tl=$tl+$liter;
	?><tr>
	<?php		
	}else{?>
		<td colspan="6">No record(s) found.</td>
	<?php }
	}
	?>
	<tr><td colspan="2" align="right"><b>Total</b></td><td ><?php echo $tl; ?> ltrs</td><td>Rs. <?php echo $tp; ?></td><td colspan="3"></td></tr>
	</tbody>
	</table>
<?php
}
?>
            </div>
        </div>
    </body>
	
<?php
include("footer.php");
}else{
	echo "Invalid User";
}
?>
</html>
