<?php
$date=date('Y-m-d');
include("user_sidebar.php");
if($_SESSION['user_type']=='User'){
?>
<style>
tr{
	height:auto;
	margin:50px;
}
</style>
<title>Feedback Report</title>
<section id="content"> <section class="vbox"> 
				<section class="scrollable padder"> 
						
						
					<div style="height:800px; align:center">
					<br>
					<form method="POST" action=""><table width="50%" align="center">
					<tr><td>Name</td><td>:</td><td><input type="text" name="name" value="<?php echo $row['name']; ?>" placeholder="Name" readonly>
					<input type="text" name="user_id" value="<?php echo $row['user_id']; ?>" placeholder="Name" readonly hidden><br><br></td></tr>
					<tr><td>Feedback</td><td>:</td><td><textarea name="feedback"></textarea><br><br></td></tr>
					<tr><td>Suggestion</td><td>:</td><td><textarea name="suggestion"></textarea><br><br></td></tr>
					<tr><td>Date</td><td>:</td><td><input type="text" value="<?php echo $date; ?>" placeholder="Name" readonly><br><br></td>
					<tr align="center"><td colspan="3" ><input type="submit" name="submit" value="Submit"></td></tr>
					</table></form>
		<?php 
		if(isset($_POST['submit'])){
			$user_id=$_POST['user_id'];
			$name=$_POST['name'];
			$feedback=$_POST['feedback'];
			$suggestion=$_POST['suggestion'];
			$date=date("Y-m-d");
			if($feedback!='' && $suggestion!=''){
				$fdbk="insert into feedback (user_id,name,feedback,suggestion,date_created) 
				values('$user_id','$name','$feedback','$suggestion','$date')";
				$fdbk_query=$conn->query($fdbk);
				if($fdbk_query){
					echo "Feedback given Successfully";
				}else{
					echo "Problem incurred. Contact Administartor.";
				}
			}else{
				echo "Please fill Suggestion/Feedback.";
			}
		}
		?>
					<table border="1" width="50%" align="center">
					<thead><th>Name</th><th>Feedback</th><th>Feedback Status</th><th>Suggestion</th><th>Reply</th><th>Date Given</th><th>Date Solved</th></thead>
					<tbody><?php
					$are= " select * from feedback where user_id='$session_id' ORDER BY date_created";
					$are_query=$conn->query($are);
					while($are_row=mysqli_fetch_array($are_query)){?>
						<tr><td><?php echo $are_row['name'];?></td>
						<td><pre><?php echo $are_row['feedback'];?></pre></td>
						<td><?php echo $are_row['feedback_status'];?></td>
						<td><pre><?php echo $are_row['suggestion'];?></pre></td>
						<td><pre><?php echo $are_row['reply_to_suggestion'];?></pre></td>
						<td><?php echo $are_row['date_created'];?></td>
						<td><?php echo $are_row['date_solved'];?></td></tr>
					<?php		
					}
					?></tbody>
					</table>						
					</div>
				</div> 
			</section> 
		</section> 
	</section>  
</section> 
</section> 
</section> <!-- Bootstrap --> <!-- App --> 

</body>
<?php
}else{
	echo "Invalid User/ Session Expired";
}
?>