<?php
$date=date('Y-m-d');
include("user_sidebar.php");
if($_SESSION['user_type']=='User'){
?>
<title>Bill Request</title>
<section id="content"> <section class="vbox"> 
				<section class="scrollable padder"> 
						
						
					<div style="height:800px; align:center">
					<br>
					<form method="POST" action=""><table width="50%" align="center">
					<tr><td>Name</td><td>:</td><td><input type="text" name="name" value="<?php echo $row['name']; ?>" placeholder="Name" readonly>
					<input type="text" name="user_id" value="<?php echo $row['user_id']; ?>" placeholder="Name" readonly hidden><br><br></td></tr>
					<tr><td>Month</td><td>:</td><td><select name="month" required><option></option>
					<option>January</option>
					<option>Febrauary</option>
					<option>March</option>
					<option>April</option>
					<option>May</option>
					<option>June</option>
					<option>July</option>
					<option>August</option>
					<option>September</option>
					<option>October</option>
					<option>November</option>
					<option>December</option>
					</select><br><br></td></tr>
					<tr><td>Date</td><td>:</td><td><input type="text" value="<?php echo $date; ?>" placeholder="Name" readonly><br><br></td>
					<tr align="center"><td colspan="3" ><input type="submit" name="submit" value="Send Request"></td></tr>
					</table></form>
<?php
if(isset($_POST['submit'])){
	$name=$_POST['name'];
	$user_id=$_POST['user_id'];
	$month=$_POST['month'];
	$year=date('Y');
	$date=date('Y-m-d');
	if($month!=''){
		$sel_bill="select * from bill_request where user_id='$user_id' and month='$month' and year='$year'";
		$query_bill=$conn->query($sel_bill);
		$bill_row=mysqli_num_rows($query_bill);
		if($bill_row>0){
			echo "This combination is already requested.";			
		}else{
			$advance="insert into bill_request (name,user_id,month,year,date_requested) values('$name','$user_id','$month','$year','$date')";
			$advance_query=$conn->query($advance);
			if($advance_query){
				echo "Request Success. Wait for approval of Administrator";
			}else{
				echo "Failed to request contact administrator.";
			}
		}		
	}else{
		echo "Please fill all required fields.";
	}
}
?>					
					</div>
				</div> 
<?php
include("footer.php");
?>			</section> 
		</section> 
	</section>  
</section> 
</section> 
</section> <!-- Bootstrap --> <!-- App --> 

</body>
<?php
}else{
	echo "Invalid User/ Session Expired";
}
?>