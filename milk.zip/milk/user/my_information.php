<?php
$date=date('Y-m-d');
include("user_sidebar.php");
if($_SESSION['user_type']=='User'){
?>
<style>
tr{
	height:30px;
}
</style>
<title>My Information</title>
<section id="content"> <section class="vbox"> 
	<section class="scrollable padder"> 
		<div style="height:800px; align:center;">
		<br>
			<table border='1' width="50%" align="center">
				<tr><td>Name</td><td><?php echo $row['name'];?></td><td rowspan="5">
<img src="../images/<?php $row['photo'];if($row['photo']==''){echo "default.png";}else{echo $row['photo'];}?>" alt="My Photograph" width="185px" height="auto"></td></tr>
				<tr><td>Father Name</td><td><?php echo $row['father_name'];?></td></tr>
				<tr><td>Username</td><td><?php echo $row['username'];?></td></tr>
				<tr><td>User Type</td><td><?php echo $row['user_type'];?></td></tr>
				<tr><td>Date of Birth</td><td><?php echo $row['dob'];?></td></tr>
				<tr><td>Email</td><td><?php echo $row['dob'];?></td></tr>
				<tr><td>Aadhar Number</td><td><?php echo $row['aadhar_number'];?></td><td><a href="<?php echo "../images/".$row['aadhar_pic'];?>">View Document</a></td></tr>
				<tr><td>Permanent Account Number(PAN)</td><td  colspan="2"><?php echo $row['pan'];?></td></tr>
				<tr><td>Bank Account Number</td><td><?php echo $row['bank_account_no'];?></td><td><a href="../images/<?php echo $row['bank_passbook'];?>">View Document</a></td></tr>
				<tr><td>IFSC code</td><td colspan="2"><?php echo $row['ifsc'];?></td></tr>
				<tr><td>Email</td><td colspan="2"><?php echo $row['email'];?></td></tr>
				<tr><td>Phone</td><td colspan="2"><?php echo $row['phone'];?></td></tr>
				<tr><td colspan="3"><input type="checkbox" name="accept" value="accept" checked readonly> I (<?php echo $row['name'];?>), hereby declared that I accept all terms and conditions. I declare that above mentioned
data (belongs to me) is correct as per my knowledge and belief. I bear the responsibility of any error or mistake found in my data if occur in future.</td></tr>
				<tr><td>Date:<?php echo $row['created_date'];?></td><td colspan="2">Signature:<img src="../images/<?php echo $row['sign'];?>" alt=" My signature"></td></tr>
			</table>
		</div>
	</div> 
<?php
include("footer.php");
?>	</section> 
</section> 
</section>  
</section> 
</section> 
</section>

</body>
<?php
}else{
	echo "Invalid User/ Session Expired";
}
?>