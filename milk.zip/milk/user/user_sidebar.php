<?php
//Start session
session_start();
//Check whether the session variable SESS_MEMBER_ID is present or not
if (!isset($_SESSION['id']) || (trim($_SESSION['id']) == '')) {
    header("location: index.php");
    exit();
}
$session_id=$_SESSION['id'];
include("connect_db.php");
$set="select * from users where user_id='$session_id'";
$set_query=$conn->query($set);
$row=mysqli_fetch_array($set_query);
if($_SESSION['user_type']=='User'){
?>

<link rel="stylesheet" href="../css/user_sidebar.css">
<script src="../js/user_sidebar.js"></script>
<script src="https://kit.fontawesome.com/yourcode.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<body>
<section class="vbox"> 
<header class="bg-dark dk header navbar navbar-fixed-top-xs"> 
<div class="navbar-header aside-md"> 
	<a class="btn btn-link visible-xs" data-toggle="dropdown" data-target=".nav-user"><i class="fa fa-cog"></i></a> 
</div> 
<ul class="nav navbar-nav hidden-xs"> 
	<li class="dropdown"> 
		<h3><b>Milk Management System</b></h3>
	</li> 
	
</ul> 

<ul class="nav navbar-nav navbar-right m-n hidden-xs nav-user">
	<li class="dropdown"> 
		<a href="#" class="dropdown-toggle" data-toggle="dropdown"> 
<span class="thumb-sm avatar pull-left">  &nbsp; &nbsp;<i class="fa fa-cog"></i></span> <?php echo $row['name'];?> <b class="caret"></b> 
		</a> 
		<ul class="dropdown-menu animated fadeInRight"> <span class="arrow top"></span> 
			<li> <a href="my_information.php">Profile</a> </li> 
			<li> <a href="change_password.php">Change Password</a> </li> 
			<!--<li> <a href="#"> <span class="badge bg-danger pull-right">3</span> Notifications </a> </li> -->
			<li> <a href="logout.php">Logout</a> </li> 
		</ul> 
	</li> 
</ul> 
</header> 

<section> 
<section class="hbox stretch"> <!-- .aside --> 
	<aside class="bg-dark lter aside-md hidden-print" id="nav"> 
		<section class="vbox"> 
			
			<section class="w-f scrollable"> 
				<div class="slim-scroll" data-height="auto" data-disable-fade-out="true" data-distance="0" data-size="5px" data-color="#333333">
					<!-- nav -->
					<nav class="nav-primary hidden-xs"> 
						<ul class="nav"> 
			<li class="active"> <a href="dashboard.php" class="active"> <i class="fa fa-dashboard icon"> <b class="bg-danger"></b> </i> <span>Dashboard</span> </a> </li> 
			<li> 
				<a href="#layout" > <i class="fa fa-columns icon"><b class="bg-warning"></b> </i> <span class="pull-right"> <i class="fa fa-angle-down text"></i><i class="fa fa-angle-up text-active"></i></span> <span>Reports</span> </a> 
				<ul class="nav lt"> 
					<li> 
						<a href="daily_report.php"> 
							<i class="fa fa-angle-right"></i> 
							<span>Daily Report</span> 
						</a> 
					</li> 
					<li> 
						<a href="bill_report.php"> 
							<i class="fa fa-angle-right"></i> 
							<span>Bill Reports</span> 
						</a> 
					</li> 
					<li> 
						<a href="feedback_report.php"> 
							<i class="fa fa-angle-right"></i> 
							<span>Feedback Report</span> 
						</a> 
					</li>  
					<li> 
						<a href="ratelist.php"> 
							<i class="fa fa-angle-right"></i> 
							<span>Ratelist</span> 
						</a> 
					</li> 
				</ul>
			</li> 
			<li>
				<a href="#uikit" > 
					<i class="fa fa-file-text icon"> <b class="bg-success"></b> </i> 
					<span class="pull-right"> 
						<i class="fa fa-angle-down text"></i>
						<i class="fa fa-angle-up text-active"></i> 
					</span> 
					<span>Requests</span> 
				</a> 
				<ul class="nav lt"> 
					<li> 
						<a href="advance_request.php">
							<i class="fa fa-angle-right"></i> <span>Request Advance</span> 
						</a> 
					</li>
					<li>
						<a href="bill_request.php" > 
							<i class="fa fa-angle-right"></i> 
							<span>Request Bill</span> 
						</a> 
					</li>
					<!--<li > 
						<a href="#table" > 
							<i class="fa fa-angle-down text"></i> 
							<i class="fa fa-angle-up text-active"></i> 
							<b class="badge pull-right">8</b> 
							<span>Approvals</span> 
						</a> 
						<ul class="nav bg"> 
							<li > 
								<a href="bill_approval.php" > 
									<i class="fa fa-angle-right"></i> <span>Approved Bills</span> 
								</a> 
							</li> 
							<li >
								<a href="advance_approval.php" > 
									<i class="fa fa-angle-right"></i> <span>Approved Advances</span> 
								</a> 
							</li>
						</ul> 
					</li> -->
					</ul> 
						<li > <a href="contact_us.php" > <b class="badge bg-danger pull-right">0</b> <i class="fa fa-envelope-o icon"> <b class="bg-primary dker"></b> </i> <span>Contact Us</span> </a> </li> 
					</ul>
				</nav> <!-- / nav --> 
			</div> 
		</section> 
			
				<div class="btn-group hidden-nav-xs"> 
				</div> </section>
				</aside> <!-- /.aside -->
<?php
}
?>