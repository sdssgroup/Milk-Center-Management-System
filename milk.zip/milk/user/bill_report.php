<?php
$date=date('Y-m-d');
include("user_sidebar.php");
if($_SESSION['user_type']=='User'){
?>
<title>Bill Report</title>
<section id="content"> <section class="vbox"> 
				<section class="scrollable padder"> 
						
						
					<div style="height:800px; align:center">
<br>
					<table border="1" width="50%" align="center">
					<thead><th>Name</th><th>Liters</th><th>Price</th><th>From Date</th><th>To Date</th><th>Total Days</th><th>Date Generated on</th></thead>
					<tbody><?php
					$are= " select * from bills where user_id='$session_id' ORDER BY created_date";
					$are_query=$conn->query($are);
					while($are_row=mysqli_fetch_array($are_query)){?>
						<tr><td><?php echo $are_row['name'];?></td>
						<td><?php echo $are_row['liters'];?></td>
						<td><?php echo $are_row['rate'];?></td>
						<td><?php echo $are_row['from_date'];?></td>
						<td><?php echo $are_row['to_date'];?></td>
						<td><?php echo $are_row['total_days'];?></td>
						<td><?php echo $are_row['created_date'];?></td></tr>
					<?php		
					}
					?></tbody>
					</table>	  
					</div>
				</div> 
<?php
include("footer.php");
?>			</section> 
		</section> 
	</section>  
</section> 
</section> 
</section> <!-- Bootstrap --> <!-- App --> 

</body>
<?php
}else{
	echo "Invalid User/ Session Expired";
}
?>