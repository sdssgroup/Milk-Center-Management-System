<?php
$date=date('Y-m-d');
include("user_sidebar.php");
if($_SESSION['user_type']=='User'){
?>
<title><?php echo $row['name'];?> Dashboard</title>
<section id="content"> <section class="vbox"> 
				<section class="scrollable padder"> 
						
						
					<div style="height:800px;">
 <h1>Welcome, "<?php echo $row['name'];?>"</h1>
	  
					</div>
				</div> 
<?php
include("footer.php");
?>			</section> 
		</section> 
	</section>  
</section> 
</section> 
</section>

</body>
<?php
}else{
	echo "Invalid User/ Session Expired";
}
?>