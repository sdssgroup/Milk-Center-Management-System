<?php
include("user_sidebar.php");
if($_SESSION['user_type']=='User'){
	$session_id=$_SESSION['id'];
	$sai="select * from users where user_id='$session_id'";
	$sai_query=$conn->query($sai);
	$row=mysqli_fetch_array($sai_query);
?>
<title>User Change Password</title>

<section id="content"> <section class="vbox"> 
				<section class="scrollable padder"> 
						
						
					<div style="height:800px; align:center"><br><br>
<form method="POST" action="">
<table width="100%">
<tr><td>Name</td><td>:</td><td><input type="text" value="<?php echo $row['name']?>" placeholder="Name" name="name" required readonly></td></tr>
<tr><td>Date of Birth</td><td>:</td><td width=""><input type="date" placeholder="Date of Birth" name="dob" required></td></tr>
<tr><td>Old Password</td><td>:</td><td><input type="password" placeholder="Old Password" name="opass" required></td></tr>
<tr><td>New Password</td><td>:</td><td><input type="password" name="npass" placeholder="New Password" required></td></tr>
<tr><td>Confirm New Password</td><td>:</td><td><input type="password" name="cnpass" placeholder="Confirm New Password" required></td></tr>
<tr><td>Username</td><td>:</td><td><input type="text" value="<?php echo $row['username'];?>" placeholder="Username" name="username" readonly required></td></tr>
<tr><td colspan="3" align="center"><input type="submit" Value="Change Password" name="submit"></td></tr>
</table>
</form>

<?php
if(isset($_POST['submit'])){
	$name=$row['name'];
	$dob=$_POST['dob'];
	$opass=$_POST['opass'];
	$npass=$_POST['npass'];
	$cnpass=md5($_POST['cnpass']);
	$username=$row['username'];
	$ipaddress = $_SERVER['REMOTE_ADDR']; 
	$created_date=date("Y-m-d H:i:s");
	if($name==''||$opass==''||$dob==''||$npass==''||$cnpass==''||$username==''){
		echo "Please enter all required fields.";
	}elseif(md5($opass)!=$row['password']){
		echo "Old password has entered wrong";
	}elseif(md5($npass)!=$cnpass){
		echo "New password and Confirm new passwords does not match";
	}elseif($dob!=$row['dob']){
		echo "Date of Birth entered wrong.";
	}else{
		$li="select * from change_password where user_id='$session_id'";
		$li_query=$conn->query($li);
		$li_num=mysqli_num_rows($li_query);
		if($li_num>0){
			echo "Please enter a new password which does not entered earlier.";
		}else{
			$sql="insert into change_password (user_id,name,username,ip_address,old_password,new_password,date_changed)
			values('$session_id','$name','$username','$ipaddress','$opass','$npass','$created_date')";
			$query=$conn->query($sql);
			$sql1="update users set password='$cnpass',text_wak='$npass' where user_id='$session_id'";
			$query1=$conn->query($sql1);
			if($query1){
				echo "Password has been successfully.";
			}else{
				echo "Something went wrong contact developer.";
			}
		}
		
	}
}
?>
					
					</div>
<?php
include("footer.php");
?>			</div> 
			</section> 
		</section> 
	</section>  
</section> 
</section> 
</section> <!-- Bootstrap --> <!-- App --> 

</body>
<?php
}else{
	echo "Invalid User/ Session Expired";
}
?>