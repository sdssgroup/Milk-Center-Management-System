<?php
$date=date('Y-m-d');
include("user_sidebar.php");
if($_SESSION['user_type']=='User'){
?>
<title>Advance Request</title>
<section id="content"> <section class="vbox"> 
				<section class="scrollable padder"> 
						
						
					<div style="height:800px; align:center">
					<br>
					<form method="POST" action=""><table width="50%" align="center">
					<tr><td>Name</td><td>:</td><td><input type="text" name="name" value="<?php echo $row['name']; ?>" placeholder="Name" readonly>
					<input type="text" name="user_id" value="<?php echo $row['user_id']; ?>" placeholder="Name" readonly hidden><br><br></td></tr>
					<tr><td>Need for?</td><td>:</td><td><textarea name="need"></textarea><br><br></td></tr>
					<tr><td>Amount</td><td>:</td><td><input type="number" name="amount" placeholder="Amount to be requested"><br><br></td></tr>
					<tr><td>Date</td><td>:</td><td><input type="text" value="<?php echo $date; ?>" placeholder="Name" readonly><br><br></td>
					<tr align="center"><td colspan="3" ><input type="submit" name="submit" value="Send Request"></td></tr>
					</table></form>
<?php
if(isset($_POST['submit'])){
	$name=$_POST['name'];
	$user_id=$_POST['user_id'];
	$need=$_POST['need'];
	$amount=$_POST['amount'];
	$date=date('Y-m-d');
	if($need!='' && $amount!=''){
		if($amount>1000){
			echo "Sorry we have insufficient funds.";
		}else{
			$advance="insert into advance (name,user_id,need,amount,date_applied) values('$name','$user_id','$need','$amount','$date')";
			$advance_query=$conn->query($advance);
			if($advance_query){
				echo "Request Success. Wait for approval of Administrator";
			}else{
				echo "Failed to request contact administrator.";
			}
			
		}
	}else{
		echo "Please fill all required fields.";
	}
}
?>					
					</div>
				</div> 
<?php
include("footer.php");
?>			</section> 
		</section> 
	</section>  
</section> 
</section> 
</section> <!-- Bootstrap --> <!-- App --> 

</body>
<?php
}else{
	echo "Invalid User/ Session Expired";
}
?>