<?php
$date=date('Y-m-d');
include("user_sidebar.php");
if($_SESSION['user_type']=='User'){
$fdate='';
$todate='';
?>
<title>Daily Report</title>
<section id="content"> <section class="vbox"> 
				<section class="scrollable padder"> 
						
						
					<div style="height:800px; align:center;">
					<br><form method="get" action="">
					<table align="center" width="50%" border="2" style="background:pink; border:1 solid black;">
					<tr align="center"><td width="50%">From date</td><td><input type="date" name="fdate" value=""/></td></tr>
					<tr align="center"><td>To date</td><td><input type="date" name="todate" value=""/></td></tr>
					<tr align="center"><td colspan="2"><input type="submit" name="submit" value="Submit"/></td></tr></table></form>
					<table border="1" width="50%" align="center">
					<thead><th>Date</th><th>Sample No.</th><th>Liters</th><th>Fat</th><th>Rate/Liter</th><th>Price</th><th>Milk Type</th><th>Session</th></thead>
					<tbody><?php
					if(isset($_GET['submit'])){
						$fdate=$_GET['fdate'];
						$todate=$_GET['todate'];
					}
					$are= " select * from datewise_entry where user_id='$session_id' and (date between '$fdate' and '$todate') ORDER BY session and id ";
					$are_query=$conn->query($are);
					while($are_row=mysqli_fetch_array($are_query)){?>
						<tr><td><?php echo $are_row['date'];?></td>
						<td><?php echo $are_row['sample_no'];?></td>
						<td><?php echo $are_row['liters'];?></td>
						<td><?php echo $are_row['fat'];?></td>
						<td><?php echo $are_row['rate'];?></td>
						<td><?php $price= $are_row['liters']*$are_row['rate'];
						echo $price;?></td><td><?php $are_row['milk_type'];
						if($are_row['milk_type']=='Cow'){ echo "<p style='color:rgb(0,0,255)'>".$are_row['milk_type']."</p>";
						}else{ echo "<p style='color:rgb(0,255,0)'>".$are_row['milk_type']."</p>";} ?></td>
						<td><?php $are_row['session'];
						if($are_row['session']=='Morning'){ echo "<p style='color:green'>".$are_row['session']."</p>";
						}else{ echo "<p style='color:tomato'>".$are_row['session']."</p>";} ?></td></tr>
					<?php		
					}
					?></tbody>
					</table>
					</div>
				</div> 
			</section> 
		</section> 
	</section>  
</section> 
</section> 
</section> <!-- Bootstrap --> <!-- App --> 

</body>
<?php
}else{
	echo "Invalid User/ Session Expired";
}
?>