	<?php
require_once('../connect_db.php');
if(isset($_SESSION['user_type']) && $_SESSION['user_type']!=""){
	if($_SESSION['user_type']=="Administrator"){
		header('location: ../../Admin/dashboard.php');
	}elseif($_SESSION['user_type']=="User"){
		header('location:../../user/dashboard.php');
	}elseif($_SESSION['user_type']=="Management"){
		header('location:../../Management/dashboard.php');
	}else{
		echo "Invalid User";
	}
}
?>
<title>Restricted Access</title>
<div class="container">
<center>
<table width="100%" style="position:responsive"><tr><td colspan="3"><p style="text-shadow:1px 1px 1px rgba(255,163,240,1);font-weight:bold;color:#2A1FC2;background-color: ;border: 5px groove #f7b3e5;letter-spacing:2pt;word-spacing:4pt;font-size:50px;text-align:center;font-family:georgia, serif;line-height:1;width:100%;">
MILK CO-OPERATION OF TELANGANA STATE
	</p></td></tr>
<tr><td><p style="text-shadow:1px 1px 1px rgba(255,163,240,1);font-weight:bold;color:#2A1FC2;background-color: ;border: 5px groove #f7b3e5;letter-spacing:2pt;word-spacing:4pt;font-size:25px;text-align:center;font-family:georgia, serif;line-height:1;width:100%;">
Village: KADAPARTHY
	</p></td>
<td><p style="text-shadow:1px 1px 1px rgba(255,163,240,1);font-weight:bold;color:#2A1FC2;background-color: ;border: 5px groove #f7b3e5;letter-spacing:2pt;word-spacing:4pt;font-size:25px;text-align:center;font-family:georgia, serif;line-height:1;width:100%;">
Mandal: NAKREKAL
	</p></td>
<td><p style="text-shadow:1px 1px 1px rgba(255,163,240,1);font-weight:bold;color:#2A1FC2;background-color: ;border: 5px groove #f7b3e5;letter-spacing:2pt;word-spacing:4pt;font-size:25px;text-align:center;font-family:georgia, serif;line-height:1;width:100%;">
District: NALGONDA
	</p></td></tr>
	<tr height="20px"></tr>
</table>
</center>
<center>
<h1 size="12" style="color:Tomato"><marquee>Restricted Access. Alert sent to Administrator.</marquee></h1>
</div>
</div>
</div>
</html>
<?php
include("../footer.php");
?>