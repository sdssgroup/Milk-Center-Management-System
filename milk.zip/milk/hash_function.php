<?php
echo hash("crc32","BT3RR18NOV19 18951A04E3");
?>