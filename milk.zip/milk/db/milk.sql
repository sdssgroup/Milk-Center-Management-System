-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 19, 2020 at 07:36 AM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `milk`
--

-- --------------------------------------------------------

--
-- Table structure for table `advance`
--

CREATE TABLE `advance` (
  `id` int(11) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `need` text NOT NULL,
  `amount` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `transaction_type` varchar(255) NOT NULL,
  `date_applied` varchar(255) NOT NULL,
  `date_granted` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `advance`
--

INSERT INTO `advance` (`id`, `user_id`, `name`, `need`, `amount`, `status`, `transaction_type`, `date_applied`, `date_granted`) VALUES
(1, '104', 'PABBATHI SAI GIRISH', 'TEST', '400', 'Granted', 'Cash', '2020-01-16', '2020-01-16');

-- --------------------------------------------------------

--
-- Table structure for table `bills`
--

CREATE TABLE `bills` (
  `id` int(11) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `liters` varchar(255) NOT NULL,
  `rate` varchar(255) NOT NULL,
  `advance` varchar(255) NOT NULL,
  `from_date` varchar(255) NOT NULL,
  `to_date` varchar(255) NOT NULL,
  `total_days` varchar(255) NOT NULL,
  `created_date` varchar(255) NOT NULL,
  `created_time` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bills`
--

INSERT INTO `bills` (`id`, `user_id`, `name`, `liters`, `rate`, `advance`, `from_date`, `to_date`, `total_days`, `created_date`, `created_time`) VALUES
(5, '24', 'DASARI INDHRAMMA', '23.25', '739.8275', '', '2019-11-01', '2019-11-15', '14 days 0 months 00 years', '2020-01-13', '10:01:46'),
(6, '24', 'DASARI INDHRAMMA', '42.5', '1365.8525', '', '2019-11-16', '2019-11-30', '14 days 0 months 00 years', '2020-01-13', '10:17:32'),
(7, '24', 'DASARI INDHRAMMA', '50.25', '1585.4925', '', '2019-12-01', '2019-12-15', '14 days 0 months 00 years', '2020-01-13', '10:37:26'),
(9, '4', 'Rondla Kalamma', '44.75', '1293.1725', '', '2019-12-01', '2019-12-15', '14 days 0 months 00 years', '2020-01-16', '11:02:27'),
(10, '4', 'Rondla Kalamma', '46.5', '1407.8', '', '2019-12-16', '2019-12-31', '15 days 0 months 00 years', '2020-01-16', '11:03:22');

-- --------------------------------------------------------

--
-- Table structure for table `bill_request`
--

CREATE TABLE `bill_request` (
  `id` int(11) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `month` varchar(255) NOT NULL,
  `year` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `date_requested` varchar(255) NOT NULL,
  `date_approved` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bill_request`
--

INSERT INTO `bill_request` (`id`, `user_id`, `name`, `month`, `year`, `status`, `date_requested`, `date_approved`) VALUES
(3, '104', 'PABBATHI SAI GIRISH', 'September', '2020', '', '2020-01-16', '');

-- --------------------------------------------------------

--
-- Table structure for table `change_password`
--

CREATE TABLE `change_password` (
  `id` int(11) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `old_password` varchar(255) NOT NULL,
  `new_password` varchar(255) NOT NULL,
  `date_changed` varchar(255) NOT NULL,
  `ip_address` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `data`
--

CREATE TABLE `data` (
  `id` int(11) NOT NULL,
  `fat` varchar(255) NOT NULL,
  `rate` varchar(255) NOT NULL,
  `milk_type` varchar(255) NOT NULL,
  `date_modified` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `data`
--

INSERT INTO `data` (`id`, `fat`, `rate`, `milk_type`, `date_modified`) VALUES
(23, '0', '0', 'Buffalo', '05-01-2020 12:26:47'),
(24, '0.1', '0.56', 'Buffalo', '05-01-2020 12:26:47'),
(25, '0.2', '1.12', 'Buffalo', '05-01-2020 12:26:47'),
(26, '0.3', '1.6', 'Buffalo', '05-01-2020 12:26:47'),
(27, '0.4', '2.25', 'Buffalo', '05-01-2020 12:26:47'),
(28, '0.5', '2.82', 'Buffalo', '05-01-2020 12:26:47'),
(29, '0.6', '3.38', 'Buffalo', '05-01-2020 12:26:47'),
(30, '0.7', '3.94', 'Buffalo', '05-01-2020 12:26:47'),
(31, '0.8', '4.51', 'Buffalo', '05-01-2020 12:26:47'),
(32, '0.9', '5.07', 'Buffalo', '05-01-2020 12:26:47'),
(33, '1', '5.64', 'Buffalo', '05-01-2020 12:26:47'),
(34, '1.1', '6.20', 'Buffalo', '05-01-2020 12:26:47'),
(35, '1.2', '6.76', 'Buffalo', '05-01-2020 12:26:47'),
(36, '1.3', '7.33', 'Buffalo', '05-01-2020 12:26:47'),
(37, '1.4', '7.89', 'Buffalo', '05-01-2020 12:26:47'),
(38, '1.5', '8.46', 'Buffalo', '05-01-2020 12:26:47'),
(39, '1.6', '9.02', 'Buffalo', '05-01-2020 12:26:47'),
(40, '1.7', '9.58', 'Buffalo', '05-01-2020 12:26:47'),
(41, '1.8', '10.15', 'Buffalo', '05-01-2020 12:26:47'),
(42, '1.9', '10.71', 'Buffalo', '05-01-2020 12:26:47'),
(43, '2', '11.28', 'Buffalo', '05-01-2020 12:26:47'),
(44, '2.1', '11.84', 'Buffalo', '05-01-2020 12:26:47'),
(45, '2.2', '12.40', 'Buffalo', '05-01-2020 12:26:47'),
(46, '2.3', '12.97', 'Buffalo', '05-01-2020 12:26:47'),
(47, '2.4', '13.53', 'Buffalo', '05-01-2020 12:26:47'),
(48, '2.5', '14.1', 'Buffalo', '05-01-2020 12:26:47'),
(49, '2.6', '14.66', 'Buffalo', '05-01-2020 12:26:47'),
(50, '2.7', '15.22', 'Buffalo', '05-01-2020 12:26:47'),
(51, '2.8', '15.79', 'Buffalo', '05-01-2020 12:26:47'),
(52, '2.9', '16.35', 'Buffalo', '05-01-2020 12:26:47'),
(53, '3', '16.92', 'Buffalo', '05-01-2020 12:26:47'),
(54, '3.1', '17.48', 'Buffalo', '05-01-2020 12:26:47'),
(55, '3.2', '18.04', 'Buffalo', '05-01-2020 12:26:47'),
(56, '3.3', '18.61', 'Buffalo', '05-01-2020 12:26:47'),
(57, '3.4', '19.17', 'Buffalo', '05-01-2020 12:26:47'),
(58, '3.5', '19.74', 'Buffalo', '05-01-2020 12:26:47'),
(59, '3.6', '20.30', 'Buffalo', '05-01-2020 12:26:47'),
(60, '3.7', '20.86', 'Buffalo', '05-01-2020 12:26:47'),
(61, '3.8', '21.43', 'Buffalo', '05-01-2020 12:26:47'),
(62, '3.9', '21.99', 'Buffalo', '05-01-2020 12:26:47'),
(63, '4', '22.56', 'Buffalo', '05-01-2020 12:26:47'),
(64, '4.1', '23.12', 'Buffalo', '05-01-2020 12:26:47'),
(65, '4.2', '23.68', 'Buffalo', '05-01-2020 12:26:47'),
(66, '4.3', '24.25', 'Buffalo', '05-01-2020 12:26:47'),
(67, '4.4', '24.81', 'Buffalo', '05-01-2020 12:26:47'),
(68, '4.5', '25.38', 'Buffalo', '05-01-2020 12:26:47'),
(69, '4.6', '25.94', 'Buffalo', '05-01-2020 12:26:47'),
(70, '4.7', '26.50', 'Buffalo', '05-01-2020 12:26:47'),
(71, '4.8', '27.07', 'Buffalo', '05-01-2020 12:26:47'),
(72, '4.9', '27.63', 'Buffalo', '05-01-2020 12:26:47'),
(73, '5', '28.20', 'Buffalo', '05-01-2020 12:26:47'),
(74, '5.1', '28.73', 'Buffalo', '05-01-2020 12:26:47'),
(75, '5.2', '29.27', 'Buffalo', '05-01-2020 12:26:47'),
(76, '5.3', '29.80', 'Buffalo', '05-01-2020 12:26:47'),
(77, '5.4', '30.34', 'Buffalo', '05-01-2020 12:26:47'),
(78, '5.5', '30.87', 'Buffalo', '05-01-2020 12:26:47'),
(79, '5.6', '31.40', 'Buffalo', '05-01-2020 12:26:47'),
(80, '5.7', '31.94', 'Buffalo', '05-01-2020 12:26:47'),
(81, '5.8', '32.47', 'Buffalo', '05-01-2020 12:26:47'),
(82, '5.9', '33.01', 'Buffalo', '05-01-2020 12:26:47'),
(83, '6', '33.54', 'Buffalo', '05-01-2020 12:26:47'),
(84, '6.1', '34.07', 'Buffalo', '05-01-2020 12:26:47'),
(85, '6.2', '34.61', 'Buffalo', '05-01-2020 12:26:47'),
(86, '6.3', '35.14', 'Buffalo', '05-01-2020 12:26:47'),
(87, '6.4', '35.68', 'Buffalo', '05-01-2020 12:26:47'),
(88, '6.5', '36.21', 'Buffalo', '05-01-2020 12:26:47'),
(89, '6.6', '36.74', 'Buffalo', '05-01-2020 12:26:47'),
(90, '6.7', '37.28', 'Buffalo', '05-01-2020 12:26:47'),
(91, '6.8', '37.81', 'Buffalo', '05-01-2020 12:26:47'),
(92, '6.9', '38.35', 'Buffalo', '05-01-2020 12:26:47'),
(93, '7', '38.88', 'Buffalo', '05-01-2020 12:26:47'),
(94, '7.1', '39.41', 'Buffalo', '05-01-2020 12:26:47'),
(95, '7.2', '39.95', 'Buffalo', '05-01-2020 12:26:47'),
(96, '7.3', '40.48', 'Buffalo', '05-01-2020 12:26:47'),
(97, '7.4', '41.02', 'Buffalo', '05-01-2020 12:26:47'),
(98, '7.5', '41.55', 'Buffalo', '05-01-2020 12:26:47'),
(99, '7.6', '42.08', 'Buffalo', '05-01-2020 12:26:47'),
(100, '7.7', '42.62', 'Buffalo', '05-01-2020 12:26:47'),
(101, '7.8', '43.15', 'Buffalo', '05-01-2020 12:26:47'),
(102, '7.9', '43.69', 'Buffalo', '05-01-2020 12:26:47'),
(103, '8', '44.22', 'Buffalo', '05-01-2020 12:26:47'),
(104, '8.1', '44.75', 'Buffalo', '05-01-2020 12:26:47'),
(105, '8.2', '45.29', 'Buffalo', '05-01-2020 12:26:47'),
(106, '8.3', '45.82', 'Buffalo', '05-01-2020 12:26:47'),
(107, '8.4', '46.36', 'Buffalo', '05-01-2020 12:26:47'),
(108, '8.5', '46.89', 'Buffalo', '05-01-2020 12:26:47'),
(109, '8.6', '47.42', 'Buffalo', '05-01-2020 12:26:47'),
(110, '8.7', '47.96', 'Buffalo', '05-01-2020 12:26:47'),
(111, '8.8', '48.49', 'Buffalo', '05-01-2020 12:26:47'),
(112, '8.9', '49.03', 'Buffalo', '05-01-2020 12:26:47'),
(113, '9', '49.56', 'Buffalo', '05-01-2020 12:26:47'),
(114, '9.1', '50.09', 'Buffalo', '05-01-2020 12:26:47'),
(115, '9.2', '50.63', 'Buffalo', '05-01-2020 12:26:47'),
(116, '9.3', '51.16', 'Buffalo', '05-01-2020 12:26:47'),
(117, '9.4', '51.70', 'Buffalo', '05-01-2020 12:26:47'),
(118, '9.5', '52.23', 'Buffalo', '05-01-2020 12:26:47'),
(119, '9.6', '52.76', 'Buffalo', '05-01-2020 12:26:47'),
(120, '9.7', '53.20', 'Buffalo', '05-01-2020 12:26:47'),
(121, '9.8', '53.83', 'Buffalo', '05-01-2020 12:26:47'),
(122, '9.9', '54.37', 'Buffalo', '05-01-2020 12:26:47'),
(123, '10', '54.90', 'Buffalo', '05-01-2020 12:26:47'),
(124, '10.1', '55.43', 'Buffalo', '05-01-2020 12:26:47'),
(125, '10.2', '55.97', 'Buffalo', '05-01-2020 12:26:47'),
(126, '10.3', '56.50', 'Buffalo', '05-01-2020 12:26:47'),
(127, '10.4', '57.04', 'Buffalo', '05-01-2020 12:26:47'),
(128, '10.5', '57.57', 'Buffalo', '05-01-2020 12:26:47'),
(129, '10.6', '58.10', 'Buffalo', '05-01-2020 12:26:47'),
(130, '10.7', '58.64', 'Buffalo', '05-01-2020 12:26:47'),
(131, '10.8', '59.17', 'Buffalo', '05-01-2020 12:26:47'),
(132, '10.9', '59.71', 'Buffalo', '05-01-2020 12:26:47'),
(133, '11', '60.24', 'Buffalo', '05-01-2020 12:26:47'),
(134, '11.1', '60.77', 'Buffalo', '05-01-2020 12:26:47'),
(135, '11.2', '61.31', 'Buffalo', '05-01-2020 12:26:47'),
(136, '11.3', '61.84', 'Buffalo', '05-01-2020 12:26:47'),
(137, '11.4', '62.38', 'Buffalo', '05-01-2020 12:26:47'),
(138, '11.5', '62.91', 'Buffalo', '05-01-2020 12:26:47'),
(139, '11.6', '63.44', 'Buffalo', '05-01-2020 12:26:47'),
(140, '11.7', '63.98', 'Buffalo', '05-01-2020 12:26:47'),
(141, '11.8', '64.51', 'Buffalo', '05-01-2020 12:26:47'),
(142, '11.9', '65.05', 'Buffalo', '05-01-2020 12:26:47'),
(143, '12', '65.58', 'Buffalo', '05-01-2020 12:26:47'),
(144, '0', '0', 'Cow', '05-01-2020 12:26:47'),
(145, '0.1', '0.82', 'Cow', '05-01-2020 12:26:47'),
(146, '0.2', '1.64', 'Cow', '05-01-2020 12:26:47'),
(147, '0.3', '2.46', 'Cow', '05-01-2020 12:26:47'),
(148, '0.4', '3.28', 'Cow', '05-01-2020 12:26:47'),
(149, '0.5', '4.11', 'Cow', '05-01-2020 12:26:47'),
(150, '0.6', '4.93', 'Cow', '05-01-2020 12:26:47'),
(151, '0.7', '5.75', 'Cow', '05-01-2020 12:26:47'),
(152, '0.8', '6.57', 'Cow', '05-01-2020 12:26:47'),
(153, '0.9', '7.39', 'Cow', '05-01-2020 12:26:47'),
(154, '1', '8.22', 'Cow', '05-01-2020 12:26:47'),
(155, '1.1', '9.04', 'Cow', '05-01-2020 12:26:47'),
(156, '1.2', '9.86', 'Cow', '05-01-2020 12:26:47'),
(157, '1.3', '10.68', 'Cow', '05-01-2020 12:26:47'),
(158, '1.4', '11.50', 'Cow', '05-01-2020 12:26:47'),
(159, '1.5', '12.33', 'Cow', '05-01-2020 12:26:47'),
(160, '1.6', '13.15', 'Cow', '05-01-2020 12:26:47'),
(161, '1.7', '13.97', 'Cow', '05-01-2020 12:26:47'),
(162, '1.8', '14.79', 'Cow', '05-01-2020 12:26:47'),
(163, '1.9', '15.61', 'Cow', '05-01-2020 12:26:47'),
(164, '2', '16.44', 'Cow', '05-01-2020 12:26:47'),
(165, '2.1', '17.26', 'Cow', '05-01-2020 12:26:47'),
(166, '2.2', '18.08', 'Cow', '05-01-2020 12:26:47'),
(167, '2.3', '18.90', 'Cow', '05-01-2020 12:26:47'),
(168, '2.4', '19.72', 'Cow', '05-01-2020 12:26:47'),
(169, '2.5', '20.55', 'Cow', '05-01-2020 12:26:47'),
(170, '2.6', '21.37', 'Cow', '05-01-2020 12:26:47'),
(171, '2.7', '22.19', 'Cow', '05-01-2020 12:26:47'),
(172, '2.8', '23.01', 'Cow', '05-01-2020 12:26:47'),
(173, '2.9', '23.83', 'Cow', '05-01-2020 12:26:47'),
(174, '3', '24.66', 'Cow', '05-01-2020 12:26:47'),
(175, '3.1', '24.85', 'Cow', '05-01-2020 12:26:47'),
(176, '3.2', '25.05', 'Cow', '05-01-2020 12:26:47'),
(177, '3.3', '25.25', 'Cow', '05-01-2020 12:26:47'),
(178, '3.4', '25.44', 'Cow', '05-01-2020 12:26:47'),
(179, '3.5', '25.64', 'Cow', '05-01-2020 12:26:47'),
(180, '3.6', '25.84', 'Cow', '05-01-2020 12:26:47'),
(181, '3.7', '26.03', 'Cow', '05-01-2020 12:26:47'),
(182, '3.8', '26.23', 'Cow', '05-01-2020 12:26:47'),
(183, '3.9', '26.43', 'Cow', '05-01-2020 12:26:47'),
(184, '4', '26.63', 'Cow', '05-01-2020 12:26:47'),
(185, '4.1', '26.82', 'Cow', '05-01-2020 12:26:47'),
(186, '4.2', '27.02', 'Cow', '05-01-2020 12:26:47'),
(187, '4.3', '27.22', 'Cow', '05-01-2020 12:26:47'),
(188, '4.4', '27.41', 'Cow', '05-01-2020 12:26:47'),
(189, '4.5', '27.61', 'Cow', '05-01-2020 12:26:47'),
(190, '4.6', '27.81', 'Cow', '05-01-2020 12:26:47'),
(191, '4.7', '28.01', 'Cow', '05-01-2020 12:26:47'),
(192, '4.8', '28.21', 'Cow', '05-01-2020 12:26:47'),
(193, '4.9', '28.41', 'Cow', '05-01-2020 12:26:47'),
(194, '5', '30.0', 'Cow', '05-01-2020 12:26:47');

-- --------------------------------------------------------

--
-- Table structure for table `datewise_entry`
--

CREATE TABLE `datewise_entry` (
  `id` int(11) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `sample_no` varchar(255) NOT NULL,
  `milk_type` varchar(255) NOT NULL DEFAULT 'Buffalo',
  `liters` varchar(255) NOT NULL,
  `fat` varchar(255) NOT NULL,
  `rate` varchar(255) NOT NULL,
  `session` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `datewise_entry`
--

INSERT INTO `datewise_entry` (`id`, `user_id`, `name`, `sample_no`, `milk_type`, `liters`, `fat`, `rate`, `session`, `date`) VALUES
(38, '24', 'DASARI INDHRAMMA', '20', 'Buffalo', '1.50', '6.4', '35.68', 'Morning', '2019-11-01'),
(39, '24', 'DASARI INDHRAMMA', '13', 'Buffalo', '1.0', '5.9', '33.01', 'Morning', '2019-11-02'),
(40, '24', 'DASARI INDHRAMMA', '30', 'Buffalo', '1.5', '6.7', '37.28', 'Morning', '2019-11-03'),
(41, '24', 'DASARI INDHRAMMA', '36', 'Buffalo', '1.0', '4.6', '25.94', 'Morning', '2019-11-04'),
(42, '24', 'DASARI INDHRAMMA', '7', 'Buffalo', '1.5', '4.5', '25.38', 'Morning', '2019-11-05'),
(43, '24', 'DASARI INDHRAMMA', '25', 'Buffalo', '2.0', '6', '33.54', 'Morning', '2019-11-06'),
(44, '24', 'DASARI INDHRAMMA', '25', 'Buffalo', '1.25', '5.1', '28.73', 'Morning', '2019-11-07'),
(45, '24', 'DASARI INDHRAMMA', '20', 'Buffalo', '1.0', '5.4', '30.34', 'Morning', '2019-11-08'),
(46, '24', 'DASARI INDHRAMMA', '21', 'Buffalo', '1.25', '5.2', '29.27', 'Morning', '2019-11-09'),
(47, '24', 'DASARI INDHRAMMA', '23', 'Buffalo', '2.0', '5.8', '32.47', 'Morning', '2019-11-10'),
(48, '24', 'DASARI INDHRAMMA', '24', 'Buffalo', '1.25', '5.9', '33.01', 'Morning', '2019-11-11'),
(49, '24', 'DASARI INDHRAMMA', '28', 'Buffalo', '2.5', '6.2', '34.61', 'Morning', '2019-11-12'),
(50, '24', 'DASARI INDHRAMMA', '24', 'Buffalo', '2.0', '6.2', '34.61', 'Morning', '2019-11-13'),
(51, '24', 'DASARI INDHRAMMA', '40', 'Buffalo', '1.75', '5.1', '28.73', 'Morning', '2019-11-14'),
(52, '24', 'DASARI INDHRAMMA', '31', 'Buffalo', '1.75', '5.2', '29.27', 'Morning', '2019-11-15'),
(53, '24', 'DASARI INDHRAMMA', '29', 'Buffalo', '3.75', '5.6', '31.40', 'Morning', '2019-11-16'),
(54, '24', 'DASARI INDHRAMMA', '13', 'Buffalo', '4.0', '6', '33.54', 'Morning', '2019-11-17'),
(55, '24', 'DASARI INDHRAMMA', '33', 'Buffalo', '4.0', '5.4', '30.34', 'Morning', '2019-11-18'),
(56, '24', 'DASARI INDHRAMMA', '31', 'Buffalo', '3.5', '5.6', '31.40', 'Morning', '2019-11-19'),
(57, '24', 'DASARI INDHRAMMA', '40', 'Buffalo', '3.75', '6.1', '34.07', 'Morning', '2019-11-20'),
(58, '24', 'DASARI INDHRAMMA', '20', 'Buffalo', '3.0', '5.7', '31.94', 'Morning', '2019-11-21'),
(59, '24', 'DASARI INDHRAMMA', '25', 'Buffalo', '4.0', '5.6', '31.40', 'Morning', '2019-11-22'),
(60, '24', 'DASARI INDHRAMMA', '21', 'Buffalo', '3.0', '5.6', '31.40', 'Morning', '2019-11-23'),
(61, '24', 'DASARI INDHRAMMA', '12', 'Buffalo', '2.0', '5.8', '32.47', 'Morning', '2019-11-24'),
(62, '24', 'DASARI INDHRAMMA', '17', 'Buffalo', '0.75', '5.4', '30.34', 'Morning', '2019-11-25'),
(63, '24', 'DASARI INDHRAMMA', '25', 'Buffalo', '1.75', '5.8', '32.47', 'Morning', '2019-11-26'),
(64, '24', 'DASARI INDHRAMMA', '25', 'Buffalo', '2.0', '6.8', '37.81', 'Morning', '2019-11-27'),
(65, '24', 'DASARI INDHRAMMA', '28', 'Buffalo', '2.25', '4.8', '27.07', 'Morning', '2019-11-28'),
(66, '24', 'DASARI INDHRAMMA', '20', 'Buffalo', '2.0', '5.9', '33.01', 'Morning', '2019-11-29'),
(68, '24', 'DASARI INDHRAMMA', '30', 'Buffalo', '2.75', '6', '33.54', 'Morning', '2019-11-30'),
(69, '24', 'DASARI INDHRAMMA', '25', 'Buffalo', '3.0', '5.7', '31.94', 'Morning', '2019-12-01'),
(70, '24', 'DASARI INDHRAMMA', '36', 'Buffalo', '3.0', '5.6', '31.40', 'Morning', '2019-12-02'),
(71, '24', 'DASARI INDHRAMMA', '31', 'Buffalo', '3.75', '5.6', '31.40', 'Morning', '2019-12-03'),
(72, '24', 'DASARI INDHRAMMA', '38', 'Buffalo', '2.75', '6', '33.54', 'Morning', '2019-12-04'),
(73, '24', 'DASARI INDHRAMMA', '24', 'Buffalo', '3.5', '5.8', '32.47', 'Morning', '2019-12-05'),
(74, '24', 'DASARI INDHRAMMA', '28', 'Buffalo', '3.75', '5.8', '32.47', 'Morning', '2019-12-06'),
(75, '24', 'DASARI INDHRAMMA', '33', 'Buffalo', '3.0', '6.2', '34.61', 'Morning', '2019-12-07'),
(76, '24', 'DASARI INDHRAMMA', '12', 'Buffalo', '4.0', '6.1', '34.07', 'Morning', '2019-12-09'),
(77, '24', 'DASARI INDHRAMMA', '33', 'Buffalo', '4.0', '5.5', '30.87', 'Morning', '2019-12-10'),
(78, '24', 'DASARI INDHRAMMA', '26', 'Buffalo', '3.5', '5.5', '30.87', 'Morning', '2019-12-11'),
(79, '24', 'DASARI INDHRAMMA', '27', 'Buffalo', '4.25', '5.9', '33.01', 'Morning', '2019-12-12'),
(81, '24', 'DASARI INDHRAMMA', '31', 'Buffalo', '3.5', '5', '28.20', 'Morning', '2019-12-13'),
(82, '24', 'DASARI INDHRAMMA', '31', 'Buffalo', '3.75', '5.1', '28.73', 'Morning', '2019-12-14'),
(83, '24', 'DASARI INDHRAMMA', '36', 'Buffalo', '4.5', '5.2', '29.27', 'Morning', '2019-12-15'),
(84, '4', 'Rondla Kalamma', '11', 'Buffalo', '2.75', '3.5', '19.74', 'Morning', '2019-12-01'),
(85, '4', 'Rondla Kalamma', '7', 'Buffalo', '3.0', '5.6', '31.40', 'Morning', '2019-12-02'),
(86, '4', 'Rondla Kalamma', '9', 'Buffalo', '2.5', '5.9', '33.01', 'Morning', '2019-12-03'),
(87, '4', 'Rondla Kalamma', '11', 'Buffalo', '3.0', '5.3', '29.80', 'Morning', '2019-12-04'),
(88, '4', 'Rondla Kalamma', '3', 'Buffalo', '3.0', '5.6', '31.40', 'Morning', '2019-12-05'),
(89, '4', 'Rondla Kalamma', '16', 'Buffalo', '3.25', '5.5', '30.87', 'Morning', '2019-12-06'),
(90, '4', 'Rondla Kalamma', '17', 'Buffalo', '3.0', '5.1', '28.73', 'Morning', '2019-12-07'),
(91, '4', 'Rondla Kalamma', '15', 'Buffalo', '3.25', '5.7', '31.94', 'Morning', '2019-12-08'),
(92, '4', 'Rondla Kalamma', '19', 'Buffalo', '3.0', '4.4', '24.81', 'Morning', '2019-12-09'),
(93, '4', 'Rondla Kalamma', '6', 'Buffalo', '3.0', '5.1', '28.73', 'Morning', '2019-12-10'),
(95, '4', 'Rondla Kalamma', '13', 'Buffalo', '3.0', '5', '28.20', 'Morning', '2019-12-11'),
(96, '4', 'Rondla Kalamma', '7', 'Buffalo', '3.0', '5.1', '28.73', 'Morning', '2019-12-12'),
(97, '4', 'Rondla Kalamma', '13', 'Buffalo', '3.0', '4.8', '27.07', 'Morning', '2019-12-13'),
(98, '4', 'Rondla Kalamma', '18', 'Buffalo', '3.0', '5.4', '30.34', 'Morning', '2019-12-14'),
(99, '4', 'Rondla Kalamma', '12', 'Buffalo', '3.0', '5', '28.20', 'Morning', '2019-12-15'),
(100, '4', 'Rondla Kalamma', '8', 'Buffalo', '3.0', '5.3', '29.80', 'Morning', '2019-12-16'),
(101, '4', 'Rondla Kalamma', '8', 'Buffalo', '3.0', '5.3', '29.80', 'Morning', '2019-12-17'),
(102, '4', 'Rondla Kalamma', '7', 'Buffalo', '3.0', '5.2', '29.27', 'Morning', '2019-12-18'),
(103, '4', 'Rondla Kalamma', '8', 'Buffalo', '3.0', '5', '28.20', 'Morning', '2019-12-19'),
(104, '4', 'Rondla Kalamma', '16', 'Buffalo', '3.0', '5.4', '30.34', 'Morning', '2019-12-20'),
(106, '4', 'Rondla Kalamma', '18', 'Buffalo', '2.0', '5.3', '29.80', 'Morning', '2019-12-21'),
(107, '4', 'Rondla Kalamma', '12', 'Buffalo', '2.5', '5.6', '31.40', 'Morning', '2019-12-22'),
(108, '4', 'Rondla Kalamma', '5', 'Buffalo', '2.75', '5', '28.20', 'Morning', '2019-12-23'),
(109, '4', 'Rondla Kalamma', '10', 'Buffalo', '3.0', '5.3', '29.80', 'Morning', '2019-12-24'),
(110, '4', 'Rondla Kalamma', '15', 'Buffalo', '3.0', '5.3', '29.80', 'Morning', '2019-12-25'),
(111, '4', 'Rondla Kalamma', '6', 'Buffalo', '3.0', '5.3', '29.80', 'Morning', '2019-12-26'),
(112, '4', 'Rondla Kalamma', '7', 'Buffalo', '3.25', '5.3', '29.80', 'Morning', '2019-12-27'),
(113, '4', 'Rondla Kalamma', '5', 'Buffalo', '3.0', '5.7', '31.94', 'Morning', '2019-12-28'),
(114, '4', 'Rondla Kalamma', '5', 'Buffalo', '3.0', '5.7', '31.94', 'Morning', '2019-12-29'),
(115, '4', 'Rondla Kalamma', '9', 'Buffalo', '3.0', '6', '33.54', 'Morning', '2019-12-30'),
(116, '4', 'Rondla Kalamma', '11', 'Buffalo', '3.0', '5.5', '30.87', 'Morning', '2019-12-31'),
(218, '15', 'DUBBAKA MANGAMMA', '29', 'Buffalo', '2.25', '4.2', '23.68', 'Evening', '2019-12-01'),
(219, '70', 'KUNTLA YADAMMA', '5', 'Buffalo', '1.0', '4.5', '25.38', 'Evening', '2019-12-01'),
(220, '1', 'YANALA YADAMMA', '24', 'Buffalo', '2.25', '6.5', '36.21', 'Morning', '2019-12-01'),
(221, '3', 'YATHAKULA JAYAMMA SOMAIAH', '3', 'Buffalo', '3.5', '5.9', '33.01', 'Morning', '2019-12-01'),
(222, '5', 'Pandiri Kalamma', '35', 'Buffalo', '0.5', '6', '33.54', 'Morning', '2019-12-01'),
(223, '6', 'Pandiri Nirmala', '20', 'Buffalo', '1.75', '6.2', '34.61', 'Morning', '2019-12-01'),
(224, '7', 'Kondakindhi Varalaxmi', '19', 'Buffalo', '1.75', '7', '38.88', 'Morning', '2019-12-01'),
(225, '13', 'Mukkera Parijatha', '26', 'Buffalo', '0.5', '6.2', '34.61', 'Morning', '2019-12-01'),
(226, '15', 'DUBBAKA MANGAMMA', '28', 'Buffalo', '1.0', '8.8', '48.49', 'Morning', '2019-12-01'),
(227, '16', 'YATHAKULA VIJAYALAXMI', '32', 'Buffalo', '7.0', '6.2', '34.61', 'Morning', '2019-12-01'),
(228, '25', 'SINGARI SATHAMMMA BAKKAIAH', '12', 'Buffalo', '1.0', '5.8', '32.47', 'Morning', '2019-12-01'),
(229, '26', 'VEMULA SHAILAJA KRISHNA', '21', 'Buffalo', '0.5', '6.9', '38.35', 'Morning', '2019-12-01'),
(230, '30', 'VADAPALLY SHANKARAIAH', '37', 'Buffalo', '1.25', '9.1', '50.09', 'Morning', '2019-12-01'),
(231, '44', '44', '1', 'Buffalo', '2.5', '3.8', '21.43', 'Morning', '2019-12-01'),
(232, '47', '47', '3', 'Buffalo', '1.5', '4.5', '25.38', 'Morning', '2019-12-01'),
(233, '48', '48', '16', 'Buffalo', '1.75', '4.7', '26.50', 'Morning', '2019-12-01'),
(234, '52', '52', '15', 'Buffalo', '2.0', '4.8', '27.07', 'Morning', '2019-12-01'),
(235, '60', '60', '14', 'Buffalo', '2.25', '7.2', '39.95', 'Morning', '2019-12-01'),
(236, '66', '66', '31', 'Buffalo', '3.5', '6.4', '35.68', 'Morning', '2019-12-01'),
(237, '67', 'KOMMANABOINA RENUKA', '7', 'Buffalo', '0.5', '8.1', '44.75', 'Morning', '2019-12-01'),
(238, '68', 'SINGARI MAHALAKSHMI', '33', 'Buffalo', '0.5', '8.5', '46.89', 'Morning', '2019-12-01'),
(239, '69', 'YANALA SUJATHA', '18', 'Buffalo', '5.0', '5.2', '29.27', 'Morning', '2019-12-01'),
(240, '70', 'KUNTLA YADAMMA', '4', 'Buffalo', '2.0', '8.2', '45.29', 'Morning', '2019-12-01'),
(241, '71', 'KOLLU KALAMMA SAIDULU', '23', 'Buffalo', '2.5', '5.8', '32.47', 'Morning', '2019-12-01'),
(242, '72', 'PANDIRI BIXAMAMMA', '9', 'Buffalo', '2.0', '5.3', '29.80', 'Morning', '2019-12-01'),
(243, '73', 'YATHAKULA POOLAMMA', '2', 'Buffalo', '1.5', '6.2', '34.61', 'Morning', '2019-12-01'),
(244, '75', 'MUKKERA SUNITHA', '36', 'Buffalo', '2.0', '4', '22.56', 'Morning', '2019-12-01'),
(245, '76', 'JEEDIPALLY VENKATAMMA', '22', 'Buffalo', '2.0', '5', '28.20', 'Morning', '2019-12-01'),
(246, '77', 'SINGARI YADAMMA', '8', 'Buffalo', '2.0', '4', '22.56', 'Morning', '2019-12-01'),
(247, '78', 'GOLLALA PARVATHAMMA', '100', 'Cow', '11.0', '3', '24.66', 'Morning', '2019-12-01'),
(248, '79', 'GORLA LAXMAMMA BIXAM', '6', 'Buffalo', '1', '9.7', '53.20', 'Morning', '2019-12-01'),
(249, '81', 'KALLU SUNITHA', '17', 'Buffalo', '1', '7.3', '40.48', 'Morning', '2019-12-01'),
(250, '83', 'PANDIRI RAJITHA SAIDULU', '10', 'Buffalo', '1.5', '4.2', '23.68', 'Morning', '2019-12-01');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(11) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `feedback` text NOT NULL,
  `feedback_status` varchar(255) NOT NULL,
  `suggestion` text NOT NULL,
  `reply_to_suggestion` varchar(255) NOT NULL,
  `date_created` varchar(255) NOT NULL,
  `date_solved` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `user_id`, `name`, `feedback`, `feedback_status`, `suggestion`, `reply_to_suggestion`, `date_created`, `date_solved`) VALUES
(1, '105', 'PABBATHI SHIVA SAI', 'Awesome TEST!!', 'Solved', 'Improve to the better version of MMS 2.0', 'Test Case Hloo', '2019-01-03', '2020-01-05'),
(2, '104', 'PABBATHI SAI GIRISH', 'TEST', 'Solved', 'TEST', 'TEST', '2020-01-16', '2020-01-16'),
(3, '24', 'DASARI INDHRAMMA', 'Good Service by MMS', 'Solved', 'Awesome Idea', 'Thank you for your valuable feedback. We will improve much better to reach the highest position.', '2020-01-13', '2020-01-13');

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int(11) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `file_location` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `created_date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `user_id`, `name`, `title`, `description`, `file_location`, `status`, `created_date`) VALUES
(1, '101', 'PABBATHI SREESHAILAM', 'Bills sanctioned for the months of November and December, 2019', 'test,\r\ntest\r\ntest\r\ntest\r\ntest\r\ntset\r\n', 'Bills sanctioned for the months of November and December, 2019.pdf', 'Active', '2019-12-26');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `text_wak` varchar(255) NOT NULL,
  `dob` varchar(255) NOT NULL,
  `father_name` varchar(255) NOT NULL,
  `aadhar_number` varchar(255) NOT NULL,
  `aadhar_pic` varchar(255) NOT NULL,
  `pan` varchar(255) NOT NULL,
  `bank_account_no` varchar(255) NOT NULL,
  `bank_passbook` varchar(255) NOT NULL,
  `ifsc` varchar(255) NOT NULL,
  `photo` varchar(255) NOT NULL,
  `sign` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `user_type` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `created_date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `name`, `password`, `text_wak`, `dob`, `father_name`, `aadhar_number`, `aadhar_pic`, `pan`, `bank_account_no`, `bank_passbook`, `ifsc`, `photo`, `sign`, `email`, `phone`, `user_type`, `status`, `created_date`) VALUES
(1, 'yadamma', 'YANALA YADAMMA', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', '2019-12-22 18:27:30'),
(3, 'ysomaiah', 'YATHAKULA JAYAMMA SOMAIAH', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', '2019-12-22 18:27:30'),
(4, 'kalamma', 'Rondla Kalamma', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', '2019-12-22 18:27:30'),
(5, 'pkalamma', 'Pandiri Kalamma', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', '2019-12-22 18:27:30'),
(6, 'pnirmala', 'Pandiri Nirmala', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', '2019-12-22 18:27:30'),
(7, 'varalaxmi', 'Kondakindhi Varalaxmi', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', '2019-12-22 18:27:30'),
(9, 'pdhanalaxmi', 'Pabbathi Dhanalaxmi', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', '2019-12-22 18:27:30'),
(10, 'msaritha', 'Maram Saritha', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', '2019-12-22 18:27:30'),
(11, 'ylaxmamma', 'Yala Laxmamma', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', '2019-12-22 18:27:30'),
(12, 'sathamma', 'Singari Sathamma Ramulu', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', '2019-12-22 18:27:30'),
(13, 'mparijatha', 'Mukkera Parijatha', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', '2019-12-22 18:27:30'),
(14, 'pshobharana', 'Pogakula Shobharani', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', '2019-12-22 18:27:30'),
(15, 'dmangamma', 'DUBBAKA MANGAMMA', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', '2019-12-22 18:27:30'),
(16, 'yvijayalaxmi', 'YATHAKULA VIJAYALAXMI', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', '2019-12-22 18:27:30'),
(17, '17', '17', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', '2019-12-22 18:27:30'),
(18, '18', '18', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', '2019-12-22 18:27:30'),
(19, '19', '19', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', '2019-12-22 18:27:30'),
(20, 'gmadhavi', 'GOUNI MADHAVI NARAYANA', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', '2019-12-22 18:27:30'),
(21, '21', '21', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', '2019-12-22 18:27:30'),
(22, 'dsridevi', 'DESHABOINA SRIDEVI', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', '2019-12-22 18:27:30'),
(23, 'mjhansi', 'MANNEM JHANSI', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', '2019-12-22 18:27:30'),
(24, 'indhramma', 'DASARI INDHRAMMA', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', 'DASARI INDHIRAMMA', '', '', '', '', '', '', '', '', '', '', 'User', 'active', '2019-12-22 18:27:30'),
(25, 'ssathamma', 'SINGARI SATHAMMMA BAKKAIAH', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', '2019-12-22 18:27:30'),
(26, 'vshailaja', 'VEMULA SHAILAJA KRISHNA', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', '2019-12-22 18:27:30'),
(27, 'kchandrakala', 'KOMMANABOINA CHANDHRAKALA', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', '2019-12-22 18:27:30'),
(28, 'kgangamma', 'KAMMALAPELLI GANGAMMA', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', '2019-12-22 18:27:30'),
(29, '29', '29', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', '2019-12-22 18:27:30'),
(30, 'vshankaraiah', 'VADAPALLY SHANKARAIAH', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', '2019-12-22 18:27:30'),
(31, '31', '31', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', '2019-12-22 18:27:30'),
(32, '32', '32', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', '2019-12-22 18:27:30'),
(33, '33', '33', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', '2019-12-22 18:27:30'),
(34, '34', '34', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', '2019-12-22 18:27:30'),
(35, '35', '35', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', '2019-12-22 18:27:30'),
(36, '36', '36', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', '2019-12-22 18:27:30'),
(37, '37', '37', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(38, '38', '38', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(39, '39', '39', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(40, '40', '40', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(41, '41', '41', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(42, '42', '42', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(43, '43', '43', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(44, '44', '44', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(45, '45', '45', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(46, '46', '46', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(47, '47', '47', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(48, '48', '48', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(49, '49', '49', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(50, '50', '50', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(51, '51', '51', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(52, '52', '52', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(53, '53', '53', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(54, '54', '54', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(55, '55', '55', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(56, '56', '56', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(57, '57', '57', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(58, '58', '58', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(59, '59', '59', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(60, '60', '60', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(61, '61', '61', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(62, '62', '62', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(63, '63', '63', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(64, '64', '64', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(65, '65', '65', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(66, '66', '66', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(67, 'krenuka', 'KOMMANABOINA RENUKA', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(68, 'smahalakmi', 'SINGARI MAHALAKSHMI', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(69, 'ysujatha', 'YANALA SUJATHA', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(70, 'kyadamma', 'KUNTLA YADAMMA', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(71, 'kchandrakala', 'KOLLU KALAMMA SAIDULU', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(72, 'pbixmamma', 'PANDIRI BIXAMAMMA', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(73, '73', 'YATHAKULA POOLAMMA', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(74, '74', 'GOLLALA NAGAMMA', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(75, '75', 'MUKKERA SUNITHA', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(76, '76', 'JEEDIPALLY VENKATAMMA', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(77, '77', 'SINGARI YADAMMA', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(78, '78', 'GOLLALA PARVATHAMMA', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(79, '79', 'GORLA LAXMAMMA BIXAM', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(80, '80', 'GARE MANEESHA', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(81, '81', 'KALLU SUNITHA', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(82, '82', 'GORLA SAIDAMMA SOMAIAH', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(83, '83', 'PANDIRI RAJITHA SAIDULU', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(84, '84', '84', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(85, '85', '85', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(86, '86', '86', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(87, '87', '87', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(88, '88', '88', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(89, '89', '89', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(90, '90', '90', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(91, '91', '91', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(92, '92', '92', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(93, '93', '93', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(94, '94', '94', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(95, '95', '95', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(96, '96', '96', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(97, '97', '97', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(98, '98', '98', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(99, '99', '99', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(100, '100', '100', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'active', ''),
(101, 'admin', 'PABBATHI SREESHAILAM', 'a4a1e4ad1643591ff2c041ff9167ff45', 'Sai@1234', '2001-06-22', '', '', '', '', '', '', '', '', '', '', '', 'Administrator', 'active', ''),
(103, 'pshivasai', 'PABBATHI SHIVA SAI', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '', '', '', '', '', '', '', '', '', '', '', '', 'User', 'blocked', ''),
(104, 'user_sai', 'PABBATHI SAI GIRISH', '81dc9bdb52d04dc20036dbd8313ed055', '1234', '2001-06-22', 'PABBATHI SREESHAILAM', '417740367480', '', 'KIMPS5735N', '100110202004571', '', 'UTIB0SSUD03', '', '', 'Saigirishpabbathi.com@gmail.com', '9948164984', 'User', 'active', '2019-12-22 18:27:30');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `advance`
--
ALTER TABLE `advance`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bills`
--
ALTER TABLE `bills`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bill_request`
--
ALTER TABLE `bill_request`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `change_password`
--
ALTER TABLE `change_password`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `data`
--
ALTER TABLE `data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `datewise_entry`
--
ALTER TABLE `datewise_entry`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `advance`
--
ALTER TABLE `advance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `bills`
--
ALTER TABLE `bills`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `bill_request`
--
ALTER TABLE `bill_request`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `change_password`
--
ALTER TABLE `change_password`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `data`
--
ALTER TABLE `data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=195;

--
-- AUTO_INCREMENT for table `datewise_entry`
--
ALTER TABLE `datewise_entry`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=258;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=107;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
